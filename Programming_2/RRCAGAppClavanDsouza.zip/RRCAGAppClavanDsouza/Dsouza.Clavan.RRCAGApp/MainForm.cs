﻿/*
 * Name: Clavan Dsouza
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 02-06-2023
 * Updated: 04-06-2023
 */

using Dsouza.Clavan.Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dsouza.Clavan.RRCAGApp
{
    /// <summary>
    /// This class represents the main from.
    /// </summary>
    public partial class MainForm : Form
    {
        /// <summary>
        /// 
        /// </summary>
        public MainForm()
        {
            InitializeComponent();

            mnuFileOpenSalesQuote.Click += MnuFileOpenSalesQuote_Click;
            mnuFileOpenCarWash.Click += MnuFileOpenCarWash_Click;
            mnuDataVehicles.Click += MnuDataVehicles_Click;
            mnuFileExit.Click += MnuFileExit_Click;
            mnuHelpAbout.Click += MnuHelpAbout_Click;  
        }

        /// <summary>
        /// Handles the click event Vehicle Data.
        /// </summary>
        private void MnuDataVehicles_Click(object sender, EventArgs e)
        {
            VehicleDataFrom vehicleData = new VehicleDataFrom();
            vehicleData.Show();
        }

        /// <summary>
        /// Handles the click event Car Wash.
        /// </summary>
        private void MnuFileOpenCarWash_Click(object sender, EventArgs e)
        {
            CarWashForm carWash = new CarWashForm();
            carWash.MdiParent = this;
            carWash.Show();
        }

        /// <summary>
        /// Handles the click event Sales Quote.
        /// </summary>
        private void MnuFileOpenSalesQuote_Click(object sender, EventArgs e)
        {
            SalesQuoteForm salesForm = new SalesQuoteForm();
            salesForm.MdiParent = this;
            salesForm.Show();
        }

        /// <summary>
        /// Handles the click event of Menu Exit.
        /// </summary>
        private void MnuFileExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Handles the click event of Menu About.
        /// </summary>
        private void MnuHelpAbout_Click(object sender, EventArgs e)
        {
            AboutForm form = new AboutForm();
            form.ShowDialog();
        }
    }
}
