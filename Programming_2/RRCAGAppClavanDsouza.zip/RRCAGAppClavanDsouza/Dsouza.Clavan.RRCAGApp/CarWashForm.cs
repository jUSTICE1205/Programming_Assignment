﻿/*
 * Name: Clavan Dsouza
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 02-06-2023
 * Updated: 11-07-2023
 */

using System.Collections.Generic;
using System.IO;
using System;
using System.ComponentModel;
using ACE.BIT.ADEV.CarWash;
using System.Windows.Forms;
using Dsouza.Clavan.Business;

namespace Dsouza.Clavan.RRCAGApp
{
    /// <summary>
    /// This class adds functionality for the CarWash
    /// </summary>
    public class CarWashForm : ACE.BIT.ADEV.Forms.CarWashForm
    {
        private const decimal PROVINCIALSALESTAXRATE = 0.07m;
        private const decimal GODDSANDSERVICESTAXRATE = 0.05m;

        private BindingList<String> packagesList;
        private BindingSource packagesBindingSource;

        private BindingList<CarWashItem> fragranceList;
        private BindingSource fragranceBindingSource;

        private BindingList<String> exteriorServicesList;
        private BindingSource exteriorServicesBindingSource;
        private BindingList<String> interiorServicesList;
        private BindingSource interiorServicesBindingSource;

        private CarWashInvoice carWash;
        private BindingSource carWashBindingSource;

        /// <summary>
        /// Initializes the CarWashFrom
        /// </summary>
        public CarWashForm()
        {
            this.packagesList = new BindingList<String> ();
            this.packagesBindingSource = new BindingSource();
            this.fragranceList = new BindingList<CarWashItem>();
            this.fragranceBindingSource = new BindingSource();
            this.exteriorServicesList = new BindingList<String> ();
            this.exteriorServicesBindingSource = new BindingSource();
            this.interiorServicesList = new BindingList<String>();
            this.interiorServicesBindingSource = new BindingSource();
            this.carWashBindingSource = new BindingSource();
            this.Load += CarWashForm_Load;
            this.mnuToolsGenerateInvoice.Click += MnuToolsGenerateInvoice_Click;
            this.mnuFileClose.Click += MnuFileClose_Click;
        }

        /// <summary>
        /// Handles the file close of the form.
        /// </summary>
        private void MnuFileClose_Click(object sender, EventArgs e)
        {
            this.BeginInvoke(new MethodInvoker(this.Close));
        }

        /// <summary>
        /// Sets Initial state of the form.
        /// </summary>
        private void CarWashForm_Load(object sender, System.EventArgs e)
        {
            this.Text = "Car Wash";
            this.mnuToolsGenerateInvoice.Enabled = false;
            BindControls();
            readDataFromFile();
            GetPackages();
            this.cboPackage.SelectedIndex = -1;
            this.cboFragrance.ValueMember = "Description";
            this.cboFragrance.SelectedValue = "Pine";
            this.cboPackage.SelectedIndexChanged += CalculateCarWashServices;
            this.cboFragrance.SelectedIndexChanged += CalculateCarWashServices; 
        }

        /// <summary>
        /// Reads Data from the file to populates the comboBox.
        /// </summary>
        private void readDataFromFile()
        {
            string filepath = "fragrances.txt";

            FileStream fileStream;
            fileStream = new FileStream(filepath, FileMode.Open, FileAccess.Read);

            if(!File.Exists(filepath))
            {
                String fileNotFoundErrorMessage = "Fragrance data file not found.";
                string caption = "Data File Error";
                MessageBox.Show(fileNotFoundErrorMessage, "caption", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                this.BeginInvoke(new MethodInvoker(this.Close));
            }

            StreamReader fileReader;
            fileReader = new StreamReader(fileStream);

            List<CarWashItem> fragranceList = new List<CarWashItem>();
            fragranceList.Add(new CarWashItem("Pine", 0));

            try
            {
                while (fileReader.Peek() != -1)
                {
                    string record = fileReader.ReadLine();

                    char[] delimiters = { ',' };

                    string[] fields = record.Split(delimiters);

                    string fragranceName = fields[0];
                    decimal fragrancePrice = Decimal.Parse(fields[1]);

                    if(!fragranceName.Equals("Pine"))
                    {
                        fragranceList.Add(new CarWashItem(fragranceName, fragrancePrice));
                    }
                           
                }
                fragranceList.Sort();
                foreach(CarWashItem item in fragranceList)
                {
                    this.fragranceList.Add(item);
                }
            }
            catch (Exception)
            {
                String fileNotFoundErrorMessage = "An error occurred while reading the data file.";
                string caption = "Data File Error";
                MessageBox.Show(fileNotFoundErrorMessage, "caption", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                this.BeginInvoke(new MethodInvoker(this.Close));
            }
        }

        /// <summary>
        /// Populates the Packages ComboBox.
        /// </summary>
        private void GetPackages()
        {
            String[] packages = { "Standard", "Deluxe", "Executive", "Luxury" };

            foreach (string package in packages)
            {
                this.packagesList.Add(package);
            }
        }

        /// <summary>
        /// Binds the data to the controls of the form.
        /// </summary>
        private void BindControls()
        {
            this.packagesBindingSource.DataSource = this.packagesList;
            this.cboPackage.DataSource = this.packagesBindingSource;

            this.fragranceBindingSource.DataSource = this.fragranceList;
            this.cboFragrance.DataSource = this.fragranceBindingSource;

            this.exteriorServicesBindingSource.DataSource = this.exteriorServicesList;
            this.interiorServicesBindingSource.DataSource = this.interiorServicesList;
            this.lstExterior.DataSource = this.exteriorServicesBindingSource;
            this.lstInterior.DataSource = this.interiorServicesBindingSource;

            this.carWashBindingSource.DataSource = typeof(CarWashInvoice);

            Binding subTotalBind = new Binding("Text", this.carWashBindingSource, "SubTotal", true);
            subTotalBind.FormatString = "C2";
            this.lblSubtotal.DataBindings.Add(subTotalBind);

            Binding pstBind = new Binding("Text", this.carWashBindingSource, "ProvincialSalesTaxCharged");
            this.lblProvincialSalesTax.DataBindings.Add(pstBind);

            Binding gstBind = new Binding("Text", this.carWashBindingSource, "GoodsAndServicesTaxCharged");
            this.lblGoodsAndServicesTax.DataBindings.Add(gstBind);

            Binding totalBind = new Binding("Text", this.carWashBindingSource, "Total", true);
            totalBind.FormatString = "C2";
            this.lblTotal.DataBindings.Add(totalBind);
        }

        /// <summary>
        /// Calculates the total by the interior and exterior chosen.
        /// </summary>
        private void CalculateCarWashServices(object sender, System.EventArgs e)
        {
            if(this.cboPackage.SelectedIndex > -1)
            {
                this.interiorServicesList.Clear();
                this.exteriorServicesList.Clear();

                String fragranceName = this.cboFragrance.SelectedItem.ToString();
                decimal fragranceCost = 0;
                foreach (CarWashItem fragrance in this.fragranceList)
                {
                    if (fragrance.Description == fragranceName)
                    {
                        fragranceCost = fragrance.Price;
                    }
                }

                String[] packageDescriptions = { "Standard", "Deluxe", "Executive", "Luxury" };
                decimal[] packagPrices = { 7.50m, 15.00m, 35.00m, 55.00m };
                String[] interiorServices = { "Fragrance - " + this.cboFragrance.SelectedItem.ToString(), "Shampoo Carpets", "Shampoo Upholstery", "Interior Protection Coat" };
                String[] exteriorServices = { "Hand Wash", "Hand Wax", "Wheel Polish", "Detail Engine Compartment" };

                decimal packageCost = packagPrices[this.cboPackage.SelectedIndex];

                for (int services = 0; services <= this.cboPackage.SelectedIndex; services++)
                {
                    this.interiorServicesList.Add(interiorServices[services]);
                    this.exteriorServicesList.Add(exteriorServices[services]);
                }

                this.carWash = new CarWashInvoice(PROVINCIALSALESTAXRATE, GODDSANDSERVICESTAXRATE, packageCost, fragranceCost);
                this.carWashBindingSource.DataSource = this.carWash;
                this.mnuToolsGenerateInvoice.Enabled = true;
            }
        }

        /// <summary>
        ///  Handles the invoice form.
        /// </summary>
        private void MnuToolsGenerateInvoice_Click(object sender, EventArgs e)
        {
            CarWashInvoiceForm carWashInvoiceForm = new CarWashInvoiceForm(this.carWashBindingSource);
            carWashInvoiceForm.FormClosed += CarWashInvoiceForm_FormClosed;
            carWashInvoiceForm.ShowDialog();
        }

        private void CarWashInvoiceForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.interiorServicesList.Clear();
            this.exteriorServicesList.Clear();
            this.carWashBindingSource.Clear();
            this.cboPackage.SelectedIndex = -1;
            this.cboFragrance.SelectedValue = "Pine";
            this.mnuToolsGenerateInvoice.Enabled = false;
        }
    }
}