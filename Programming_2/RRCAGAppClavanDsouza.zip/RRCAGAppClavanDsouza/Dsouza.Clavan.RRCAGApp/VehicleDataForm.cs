﻿/*
 * Name: Clavan Dsouza
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 02-06-2023
 * Updated: 04-06-2023
 */

namespace Dsouza.Clavan.RRCAGApp
{
    /// <summary>
    /// This class adds functionality for the Vehicle
    /// </summary>
    public class VehicleDataFrom : ACE.BIT.ADEV.Forms.VehicleDataForm
    {
        /// <summary>
        /// Initializes the VehicleDataForm
        /// </summary>
        public VehicleDataFrom()
        {

        }
    }

}