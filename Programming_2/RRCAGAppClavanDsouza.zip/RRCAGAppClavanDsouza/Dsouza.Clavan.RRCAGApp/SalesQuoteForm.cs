﻿/*
 * Name: Clavan Dsouza
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 02-06-2023
 * Updated: 04-06-2023
 */

using Dsouza.Clavan.Business;
using System;
using System.Windows.Forms;

namespace Dsouza.Clavan.RRCAGApp
{
    /// <summary>
    /// This class represents the Sales Quote form.
    /// </summary>
    public partial class SalesQuoteForm : Form
    {
        private SalesQuote sales;

        /// <summary>
        /// Initializes the properties of the class.
        /// </summary>
        public SalesQuoteForm()
        {
            InitializeComponent();
            this.SalesQuoteerrorProvider.BlinkStyle = ErrorBlinkStyle.NeverBlink;

            this.btnCalculateQuote.Click += BtnCalculateQuote_Click;
            this.btnReset.Click += BtnReset_Click;
            this.txtVehicleSalePrice.TextChanged += TxtBox_TextChanged;
            this.txtTradeInValue.TextChanged += TxtBox_TextChanged;
            this.chkComputerNavigation.CheckedChanged += SelectionChanged;
            this.chkLeatherInterior.CheckedChanged += SelectionChanged;
            this.chkStereoSystem.CheckedChanged += SelectionChanged;
        }



        /// <summary>
        /// Handles the click event of Calculate Quote
        /// </summary>
        private void BtnCalculateQuote_Click(object sender, EventArgs e)
        {
           CalculateQuote();
        }

        /// <summary>
        /// Calculates the Quote based on the selected options.
        /// </summary>
        private void CalculateQuote()
        {
            decimal vehicleSalePrice = GetValidVehicleSalePrice();
            decimal tradeInAmount = GetValidTradeInAmount();
            decimal salesTaxRate = 0.12m;
            Accessories accessoriesChosen = GetValidAccessories();
            ExteriorFinish exteriorFinshChosen = GetValidExteriorFinish();

            if (this.SalesQuoteerrorProvider.GetError(txtVehicleSalePrice) == String.Empty &&
                this.SalesQuoteerrorProvider.GetError(txtTradeInValue) == String.Empty)
            {

                sales = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinshChosen);

                lblVehicleSalePrice.Text = sales.VehicleSalesPrice.ToString("C");
                lblOptions.Text = sales.TotalOptions.ToString();
                lblSubTotal.Text = sales.SubTotal.ToString("C");
                lblTotal.Text = sales.Total.ToString("C");
                lblSalesTax.Text = sales.SalesTax.ToString();
                lblTradein.Text = "-" + sales.TradeInAmount.ToString();
                lblAmountDue.Text = sales.AmountDue.ToString("C");

                int numberOfYears = (int)nudNoOfYears.Value;
                decimal annualInterestRate = (nudAnnualInterestRate.Value / 100);
                decimal presentValue = sales.AmountDue;

                lblMonthlyPayment.Text = (Financial.GetPayment(annualInterestRate / 12, numberOfYears * 12, presentValue)).ToString();
            }
        }

        /// <summary>
        /// Gets the Valid the Vehicle Sale Price
        /// </summary>
        /// <returns>The Vehicle Sale Price</returns>
        private decimal GetValidVehicleSalePrice()
        {
            this.SalesQuoteerrorProvider.SetError(txtVehicleSalePrice, String.Empty);
            this.SalesQuoteerrorProvider.SetIconPadding(txtVehicleSalePrice, 3);

            int vehicleSalePrice = 0;

            if (this.txtVehicleSalePrice.Text.Equals(String.Empty))
            {
                this.SalesQuoteerrorProvider.SetError(txtVehicleSalePrice, "Vehicle price is a required field.");
            }
            else
            {
                try
                {
                    vehicleSalePrice = Int32.Parse(this.txtVehicleSalePrice.Text);

                    if (vehicleSalePrice <= 0)
                    {
                        this.SalesQuoteerrorProvider.SetError(txtVehicleSalePrice, "Vehicle price cannot be less than or equal to 0.");
                    }
                }
                catch (FormatException)
                {
                    this.SalesQuoteerrorProvider.SetError(txtVehicleSalePrice, "Vehicle price cannot contain letters or special characters.");
                }
            }

            return vehicleSalePrice;
        }

        /// <summary>
        /// Gets the Valid Trade In Amount
        /// </summary>
        /// <returns>The Trade in Amount</returns>
        private decimal GetValidTradeInAmount()
        {
            this.SalesQuoteerrorProvider.SetError(txtTradeInValue, String.Empty);
            this.SalesQuoteerrorProvider.SetIconPadding(txtTradeInValue, 3);

            int tradeInAmount = 0;

            if (this.txtTradeInValue.Text.Equals(String.Empty))
            {
                this.SalesQuoteerrorProvider.SetError(txtTradeInValue, "Trade-in value is a required field.");
            }
            else
            {
                try
                {
                    tradeInAmount = Int32.Parse(this.txtTradeInValue.Text);

                    if (tradeInAmount < 0)
                    {
                        this.SalesQuoteerrorProvider.SetError(txtTradeInValue, "Trade-in value cannot be less than 0.");
                    }
                }
                catch (FormatException)
                {
                    this.SalesQuoteerrorProvider.SetError(txtTradeInValue, "Trade-in value cannot contain letters or special characters.");
                }
            }

            if (tradeInAmount > GetValidVehicleSalePrice())
            {
                this.SalesQuoteerrorProvider.SetError(txtTradeInValue, "Trade-in value cannot exceed the vehicle sale price.");
            }

            return tradeInAmount;
        }

        /// <summary>
        /// Gets the Valid Accessories
        /// </summary>
        /// <returns>The Accessories Chosen</returns>
        private Accessories GetValidAccessories()
        {
            Accessories accessories = Accessories.None;

            if (chkComputerNavigation.Checked)
            {
                accessories = Accessories.ComputerNavigation;
            }

            if (chkLeatherInterior.Checked)
            {
                accessories = Accessories.LeatherInterior;
            }

            if (chkStereoSystem.Checked)
            {
                accessories = Accessories.StereoSystem;
            }

            if (chkComputerNavigation.Checked && chkLeatherInterior.Checked)
            {
                accessories = Accessories.LeatherAndNavigation;
            }

            if (chkComputerNavigation.Checked && chkStereoSystem.Checked)
            {
                accessories = Accessories.StereoAndNavigation;
            }

            if (chkStereoSystem.Checked && chkLeatherInterior.Checked)
            {
                accessories = Accessories.StereoAndLeather;
            }

            if (chkComputerNavigation.Checked && chkLeatherInterior.Checked && chkStereoSystem.Checked)
            {
                accessories = Accessories.All;
            }

            return accessories;
        }

        /// <summary>
        /// Gets the Valid Exterior Finish
        /// </summary>
        /// <returns>The Exterior Finish</returns>
        private ExteriorFinish GetValidExteriorFinish()
        {
            ExteriorFinish exteriorFinish = ExteriorFinish.Standard;

            if (radCustomizedDetailing.Checked)
            {
                exteriorFinish = ExteriorFinish.Custom;
            }

            if (radPearlized.Checked)
            {
                exteriorFinish = ExteriorFinish.Pearlized;
            }

            return exteriorFinish;
        }

        /// <summary>
        /// Handles the reset button of the form.
        /// </summary>
        private void BtnReset_Click(object sender, EventArgs e)
        {
            string message = "Do you want to reset the form?";
            string caption = "Reset Form";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            MessageBoxIcon icon = MessageBoxIcon.Warning;

            DialogResult result = MessageBox.Show(message, caption, buttons, icon, MessageBoxDefaultButton.Button2);

            switch(result)
            {
                case DialogResult.Yes:
                    ResetForm();
                    ClearSummary();
                    ClearFinancial();
                    break;
            }
        }

        private void ResetForm()
        {
            txtTradeInValue.Text = "0";
            txtVehicleSalePrice.Text = string.Empty;
            chkComputerNavigation.Checked = false;
            chkLeatherInterior.Checked = false;
            chkStereoSystem.Checked = false;
            radStandard.Checked = true;
            nudAnnualInterestRate.Value = 5;
            nudNoOfYears.Value = 1;
            sales = null;
            SalesQuoteerrorProvider.SetError(txtTradeInValue, String.Empty);
            SalesQuoteerrorProvider.SetError(txtVehicleSalePrice, String.Empty);
        }

        /// <summary>
        /// Clears the labels in The Summary GroupBox.
        /// </summary>
        private void ClearSummary()
        {
            lblVehicleSalePrice.Text = string.Empty;
            lblOptions.Text = string.Empty;
            lblSubTotal.Text = string.Empty;
            lblSalesTax.Text = string.Empty;
            lblTotal.Text = string.Empty;
            lblTradein.Text = string.Empty;
            lblAmountDue.Text = string.Empty;
        }

        /// <summary>
        /// Clears the labels in the Financial GroupBox.
        /// </summary>
        private void ClearFinancial()
        {
            lblMonthlyPayment.Text = string.Empty;
        }

        /// <summary>
        /// Handles the text changed event of the form.
        /// </summary>
        private void TxtBox_TextChanged(object sender, EventArgs e)
        {
            ClearSummary();
            ClearFinancial();
            this.sales = null;
        }

        /// <summary>
        /// Handles the selection changed event of the form.
        /// </summary>

        private void SelectionChanged(object sender, EventArgs e)
        {
            if (sales != null)
            {
                CalculateQuote();
            }
        }
    }
}
