﻿

using System.Windows.Forms;

namespace Dsouza.Clavan.RRCAGApp
{
    /// <summary>
    /// The class provides the functionality of generating an invoice.
    /// </summary>
    public class CarWashInvoiceForm : ACE.BIT.ADEV.Forms.CarWashInvoiceForm
    {
        private BindingSource bindingSource;

        /// <summary>
        /// Initializes the CarWashInvoiceForm.
        /// </summary>
        /// <param name="bindingSource">The binding source of the form.</param>
        public CarWashInvoiceForm(BindingSource bindingSource)
        {
            InitializeComponent();
            this.bindingSource = bindingSource;
            this.Load += CarWashInvoiceForm_Load;
        }

        /// <summary>
        /// Handles the initial state of the form.
        /// </summary>
        private void CarWashInvoiceForm_Load(object sender, System.EventArgs e)
        {
            this.Text = "Car Wash Invoice";
            BindControls();
        }

        /// <summary>
        /// Sets the data connection.
        /// </summary>
        private void BindControls()
        {
            Binding fragrancePriceBind = new Binding("Text", this.bindingSource, "FragranceCost");
            this.lblFragrancePrice.DataBindings.Add(fragrancePriceBind);

            Binding packagePriceBind = new Binding("Text", this.bindingSource, "PackageCost", true);
            packagePriceBind.FormatString = "C2";
            this.lblPackagePrice.DataBindings.Add(packagePriceBind);

            Binding subTotalBind = new Binding("Text", this.bindingSource, "SubTotal", true);
            subTotalBind.FormatString = "C2";
            this.lblSubtotal.DataBindings.Add(subTotalBind);

            Binding pstBind = new Binding("Text", this.bindingSource, "ProvincialSalesTaxCharged");
            this.lblProvincialSalesTax.DataBindings.Add(pstBind);

            Binding gstBind = new Binding("Text", this.bindingSource, "GoodsAndServicesTaxCharged");
            this.lblGoodsAndServicesTax.DataBindings.Add(gstBind);

            Binding totalBind = new Binding("Text", this.bindingSource, "Total", true);
            totalBind.FormatString = "C2";
            this.lblTotal.DataBindings.Add(totalBind);
            
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // CarWashInvoiceForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(619, 393);
            this.Name = "CarWashInvoiceForm";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
