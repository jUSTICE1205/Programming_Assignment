/*
 * Name: Clavan Dsouza
 * Program: Business Information Technology
 * Course: ADEV-1008 (234101) Programming 1
 * Created: 2023-04-03
 * Updated: 2023-04-03
 */

/**
 * Program to encapsulating the concept of a basketball player.
 * 
 * @author Clavan Dsouza
 * @version 1.0
 */
public class BasketballPlayer extends Player
{
    private int freeThrows;         //The number of free throws made by the basketball player.
    private int fieldGoals;         //The number of field goals made by the basketball player.
    private int threePointers;      //The number of three pointers made by the basketball player.

    /**
     * Initializes a new instance of the BasketballPlayer class with the specified name and number. 
     * 
     * @param name The basketball player’s name.
     * @param number The basketball player’s jersey number.
     */
    BasketballPlayer(String name, int number)
    {
        super(name, number);
        setFreeThrows(0);
        setFieldGoals(0);
        setThreePointers(0);
    }

    /**
     * Returns the number of free throws made by the basketball player.
     * 
     * @return Returns the number of free throws made by the basketball player.
     */
    public int getFreeThrows() 
    {
        return freeThrows;
    }

    /**
     * Sets the number of free throws made by the basketball player.
     * 
     * @param freeThrows The number of free throws made by the basketball player.
     */
    public void setFreeThrows(int freeThrows) 
    {
        this.freeThrows = freeThrows;
    }

    /**
     * Returns the number of field goals made by the basketball player.
     * 
     * @return Returns the number of field goals made by the basketball player.
     */
    public int getFieldGoals() 
    {
        return fieldGoals;
    }

    /**
     * Sets the number of field goals made by the basketball player.
     * 
     * @param fieldGoals The number of field goals made by the basketball player.
     */
    public void setFieldGoals(int fieldGoals) 
    {
        this.fieldGoals = fieldGoals;
    }

    /**
     * Returns the number of three pointers made by the basketball player.
     * 
     * @return Returns the number of three pointers made by the basketball player.
     */
    public int getThreePointers() 
    {
        return threePointers;
    }

    /**
     * Sets the number of three pointers made by the basketball player.
     * 
     * @param threePointers The number of three pointers made by the basketball player.
     */
    public void setThreePointers(int threePointers) 
    {
        this.threePointers = threePointers;
    }

    /**
     * Returns the total number of points accumulated by the basketball player.
     * 
     * @return Returns the total number of points accumulated by the basketball player.
     */
    @Override
    public int getPoints()
    {
        return getFreeThrows() + (getFieldGoals() * 2) + (getThreePointers() * 3);
    }

    /**
     * Returns the String representation of the player.
     * 
     * @return Returns the String representation of the player.
     */
    @Override
    public String toString()
    {
        return String.format("Basketball Player : %s [%d], Points: %d", 
                                                getName(), getNumber(), getPoints());
    }   
}
