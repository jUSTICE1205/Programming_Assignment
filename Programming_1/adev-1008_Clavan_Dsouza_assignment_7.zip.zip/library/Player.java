/*
 * Name: Clavan Dsouza
 * Program: Business Information Technology
 * Course: ADEV-1008 (234101) Programming 1
 * Created: 2023-04-03
 * Updated: 2023-04-03
 */

/**
 * Program to encapsulating the concept of a Player on a sports team. 
 * 
 * @author Clavan Dsouza
 * @version 1.0
 */
public abstract class Player
{
    private String name;    //The name of the player.
    private int number;     //The number worn on the player’s jersey.

    /**
     * Initializes a new instance of the Player class with the specified name and number.
     * 
     * @param name The player’s name.
     * @param number The player’s jersey number.
     */
    Player(String name, int number)
    {
        this.setName(name);
        this.setNumber(number);
    }

    /**
     * Returns the name of the player.
     * 
     * @return  Returns the name of the player.
     */
    public String getName() 
    {
        return name;
    }

    /**
     * Sets the name of the player.
     * 
     * @param name The player’s name.
     */
    public void setName(String name) 
    {
        this.name = name;
    }

    /**
     * Returns the player’s jersey number.
     * 
     * @return Returns the player’s jersey number.
     */
    public int getNumber() 
    {
        return number;
    }

    /**
     * Sets the player’s jersey number.
     * 
     * @param number The player’s jersey number.
     */
    public void setNumber(int number) 
    {
        this.number = number;
    }

    /**
     * Returns the total number of points accumulated by the player.
     * 
     * @return Returns the total number of points accumulated by the player.
     */
    public abstract int getPoints();

    /**
     * Returns the String representation of the player.
     * 
     * @return Returns the String representation of the player.
     */
    @Override
    public String toString()
    {
        return String.format("%s [%d]", getName(), getNumber());
    }   
}
