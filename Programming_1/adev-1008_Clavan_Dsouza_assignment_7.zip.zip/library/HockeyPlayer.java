/*
 * Name: Clavan Dsouza
 * Program: Business Information Technology
 * Course: ADEV-1008 (234101) Programming 1
 * Created: 2023-04-03
 * Updated: 2023-04-03
 */

/**
 * Program of encapsulating the concept of a hockey player. 
 * 
 * @author Clavan Dsouza
 * @version 1.0
 */
public class HockeyPlayer extends Player
{
    private int goals;      //The number of goals scored by the hockey player.
    private int assists;    //The number of assists made by the hockey player.

    /**
     * Initializes a new instance of the HockeyPlayer class with the specified name, number, goals and assists.
     * 
     * @param name The hockey player’s name.
     * @param number The hockey player’s jersey number.
     * @param goals The number of goals scored by the hockey player.
     * @param assists The number of assists made by the hockey player.
     */
    public HockeyPlayer(String name, int number, int goals, int assists)
    {
        super(name, number);
        this.setGoals(goals);
        this.setAssists(assists);
    }

    /**
     * Initializes a new instance of the HockeyPlayer class with the specified name and number. The goals and assists are set to 0.
     * 
     * @param name The player’s name.
     * @param number The player’s jersey number.
     */
    public HockeyPlayer(String name, int number)
    {
        this(name, number, 0, 0);
    }

    /**
     * Returns the number of goals scored by the hockey player.
     * 
     * @return Returns the number of goals scored by the hockey player.
     */
    public int getGoals() 
    {
        return goals;
    }

    /**
     * Sets the number of goals scored by the hockey player.
     * 
     * @param goals The number of goals scored by the hockey player.
     */
    public void setGoals(int goals) 
    {
        this.goals = goals;
    }

    /**
     * Returns the number of assists made by the hockey player.
     * 
     * @return Returns the number of assists made by the hockey player.
     */
    public int getAssists() 
    {
        return assists;
    }

    /**
     * Sets the number of assists made by the hockey player.
     * 
     * @param assists The number of assists made by the hockey player.
     */
    public void setAssists(int assists) 
    {
        this.assists = assists;
    }

    /**
     * Returns the total number of points accumulated by the hockey player.
     * A hockey player receives one point per goal and one point per assist. 
     * 
     * @return Returns the total number of points accumulated by the hockey player.
     */
    @Override
    public int getPoints()
    {
        return getGoals() + getAssists();
    }

    /**
     * Returns the String representation of the player.
     * 
     * @return Returns the String representation of the player.
     */
    @Override
    public String toString()
    {
        return String.format("Hockey Player - %s [%d], Points: %d", 
                                                getName(), getNumber(), getPoints());
    }    
}
