/*
 * Name: Clavan Dsouza
 * Program: Business Information Technology
 * Course: ADEV-1008 (234101) Programming 1
 * Created: 2023-04-03
 * Updated: 2023-04-03
 */

/**
 * Program to encapsulating the concept of Hockey player Tests. 
 * 
 * @author Clavan Dsouza
 * @version 1.0
 */
public class HockeyPlayerTests 
{
    public static void main(String[] args) 
    {
        System.out.println("HockeyPlayer(String, int)");
        System.out.println("Test #1 - Initialize the name.");
        initialize_Name();

        System.out.println();

        System.out.println("HockeyPlayer(String, int)");
        System.out.println("Test #2 - Initialize the number.");
        initialize_Number();

        System.out.println();

        System.out.println("HockeyPlayer(String, int)");
        System.out.println("Test #3 - Initialize the goals.");
        initialize_Goals();

        System.out.println();

        System.out.println("HockeyPlayer(String, int)");
        System.out.println("Test #4 - Initialize the assists.");
        initialize_Assists();

        System.out.println();
        System.out.println("HockeyPlayer(String, int, int, int)");
        System.out.println("Test #1 - Initialize the name.");
        initialize_Name_Constructor();

        System.out.println();

        System.out.println("HockeyPlayer(String, int, int, int)");
        System.out.println("Test #2 - Initialize the number.");
        initialize_Number_Constructor();

        System.out.println();

        System.out.println("HockeyPlayer(String, int, int, int)");
        System.out.println("Test #3 - Initialize the goals.");
        initialize_Goals_Constructor();

        System.out.println();

        System.out.println("HockeyPlayer(String, int, int, int)");
        System.out.println("Test #4 - Initialize the assists.");
        initialize_Assists_Constructor();

        System.out.println();

        System.out.println("setName(String) : void");
        System.out.println("Test #1 - Updates the state of name.");
        update_Name_State();

        System.out.println();

        System.out.println("setNumber(String) : void");
        System.out.println("Test #1 - Updates the state of number.");
        update_Number_State();

        System.out.println();

        System.out.println("setGoals(String) : void");
        System.out.println("Test #1 - Updates the state of goals.");
        update_Goals_State();

        System.out.println();

        System.out.println("setAssists(String) : void");
        System.out.println("Test #1 - Updates the state of assists.");
        update_Assists_State();

        System.out.println();
        
        System.out.println("getPoints() : int");
        System.out.println("Test #1 - Returns the correct number of points.");
        number_Of_Points();

        System.out.println();
        
        System.out.println("toString() : String");
        System.out.println("Test #1 - Returns the correct String representation.");
        return_To_String();
    }

    /**
     * Initialize the name.
     */
    public static void initialize_Name()
    {
        String name = "Clavan";
        int number = 10;

        HockeyPlayer target = new HockeyPlayer(name, number);

        System.out.print("Excepted : ");
        System.out.println(name);

        System.out.print("Actual   : ");
        System.out.println(target.getName());
    }

    /**
     * Initialize the number.
     */
    public static void initialize_Number()
    {
        String name = "Clavan";
        int number = 10;

        HockeyPlayer target = new HockeyPlayer(name, number);

        System.out.print("Excepted : ");
        System.out.println(number);

        System.out.print("Actual   : ");
        System.out.println(target.getNumber());

    }

    /**
     * Initialize the goals.
     */
    public static void initialize_Goals()
    {
        String name = "Clavan";
        int number = 10;

        HockeyPlayer target = new HockeyPlayer(name, number);

        System.out.print("Excepted : ");
        System.out.println(0);

        System.out.print("Actual   : ");
        System.out.println(target.getGoals());

    }

    /**
     * Initialize the assists.
     */
    public static void initialize_Assists()
    {
        String name = "Clavan";
        int number = 10;

        HockeyPlayer target = new HockeyPlayer(name, number);

        System.out.print("Excepted : ");
        System.out.println(0);

        System.out.print("Actual   : ");
        System.out.println(target.getAssists());

    }

    /**
     * Initialize the name.
     */
    public static void initialize_Name_Constructor()
    {
        String name = "Clavan";
        int number = 10;
        int goals = 3;
        int assist = 5;

        HockeyPlayer target = new HockeyPlayer(name, number, goals, assist);

        System.out.print("Excepted : ");
        System.out.println(name);

        System.out.print("Actual   : ");
        System.out.println(target.getName());
    }

    /**
     * Initialize the number.
     */
    public static void initialize_Number_Constructor()
    {
        String name = "Clavan";
        int number = 10;
        int goals = 3;
        int assist = 5;

        HockeyPlayer target = new HockeyPlayer(name, number, goals, assist);

        System.out.print("Excepted : ");
        System.out.println(number);

        System.out.print("Actual   : ");
        System.out.println(target.getNumber());

    }

    /**
     * Initialize the goals.
     */
    public static void initialize_Goals_Constructor()
    {
        String name = "Clavan";
        int number = 10;
        int goals = 3;
        int assist = 5;

        HockeyPlayer target = new HockeyPlayer(name, number, goals, assist);

        System.out.print("Excepted : ");
        System.out.println(goals);

        System.out.print("Actual   : ");
        System.out.println(target.getGoals());

    }

    /**
     * Initialize the assists.
     */
    public static void initialize_Assists_Constructor()
    {
        String name = "Clavan";
        int number = 10;
        int goals = 3;
        int assist = 5;

        HockeyPlayer target = new HockeyPlayer(name, number, goals, assist);

        System.out.print("Excepted : ");
        System.out.println(assist);

        System.out.print("Actual   : ");
        System.out.println(target.getAssists());
    }

    /**
     * Updates the state of name.
     */
    public static void update_Name_State()
    {
        String name = "Clavan";
        int number = 10;
        int goals = 3;
        int assist = 5;
        String changeName = "Dsouza";

        HockeyPlayer target = new HockeyPlayer(name, number, goals, assist);

        System.out.print("Excepted : ");
        System.out.println(changeName);

        System.out.print("Actual   : ");
        target.setName(changeName);
        System.out.println(target.getName());

        System.out.println();      
    }

    /**
     * Updates the state of number.
     */
    public static void update_Number_State()
    {
        String name = "Clavan";
        int number = 10;
        int goals = 3;
        int assist = 5;
        int changeNumber = 20;

        HockeyPlayer target = new HockeyPlayer(name, number, goals, assist);

        System.out.print("Excepted : ");
        System.out.println(changeNumber);

        System.out.print("Actual   : ");
        target.setNumber(changeNumber);
        System.out.println(target.getNumber());
    }

    /**
     * Updates the state of Goals.
     */
    public static void update_Goals_State()
    {
        String name = "Clavan";
        int number = 10;
        int goals = 3;
        int assist = 5;
        int changeGoal = 6;

        HockeyPlayer target = new HockeyPlayer(name, number, goals, assist);

        System.out.print("Excepted : ");
        System.out.println(changeGoal);

        System.out.print("Actual   : ");
        target.setGoals(changeGoal);
        System.out.println(target.getGoals());
    }

    /**
     * Updates the state of Assists.
     */
    public static void update_Assists_State()
    {
        String name = "Clavan";
        int number = 10;
        int goals = 3;
        int assist = 5;
        int changeAssist = 8;

        HockeyPlayer target = new HockeyPlayer(name, number, goals, assist);

        System.out.print("Excepted : ");
        System.out.println(changeAssist);

        System.out.print("Actual   : ");
        target.setAssists(changeAssist);
        System.out.println(target.getAssists());
    }

    /**
     * Returns the correct number of points.
     */
    public static void number_Of_Points()
    {
        String name = "Clavan";
        int number = 10;
        int goals = 10;
        int assist = 5;

        HockeyPlayer target = new HockeyPlayer(name, number, goals, assist);

        System.out.print("Excepted : ");
        System.out.println(goals + assist);

        System.out.print("Actual   : ");
        System.out.println(target.getPoints());
    }

    /**
     * Updates the state of Assists.
     */
    public static void return_To_String()
    {
        String name = "Clavan";
        int number = 10;
        int goals = 3;
        int assist = 5;

        HockeyPlayer target = new HockeyPlayer(name, number, goals, assist);

        System.out.print(target);
    }
}


