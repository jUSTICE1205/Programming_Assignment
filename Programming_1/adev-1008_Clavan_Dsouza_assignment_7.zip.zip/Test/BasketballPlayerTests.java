/*
 * Name: Clavan Dsouza
 * Program: Business Information Technology
 * Course: ADEV-1008 (234101) Programming 1
 * Created: 2023-04-03
 * Updated: 2023-04-03
 */

/**
 * Program to encapsulating the concept of BaskeyBall player Tests. 
 * 
 * @author Clavan Dsouza
 * @version 1.0
 */
public class BasketballPlayerTests 
{
    public static void main(String[] args) 
    {
        System.out.println("BasketPlayer(String, int)");
        System.out.println("Test #1 - Initialize the name.");
        initialize_Name();

        System.out.println();

        System.out.println("BasketPlayer(String, int)");
        System.out.println("Test #2 - Initialize the number.");
        initialize_Number();

        System.out.println();

        System.out.println("BasketPlayer(String, int)");
        System.out.println("Test #3 - Initialize the free throws.");
        initialize_free_throws();

        System.out.println();

        System.out.println("BasketPlayer(String, int)");
        System.out.println("Test #4 - Initialize the field goals.");
        initialize_Field_Goal();

        System.out.println();

        System.out.println("BasketPlayer(String, int)");
        System.out.println("Test #5 - Initialize the  three pointers.");
        initialize_three_pointers();

        System.out.println();

        System.out.println("setName(int) : void");
        System.out.println("Test #1 - Updates the state of name.");
        update_Number_State();

        System.out.println();

        System.out.println("setNumber(int) : void");
        System.out.println("Test #1 - Updates the state of number.");
        update_Number_State();

        System.out.println();

        System.out.println("setFreeThrows(int) : void");
        System.out.println("Test #1 - Updates the state of free throws.");
        update_free_throws_State();

        System.out.println();
        
        System.out.println("setFieldGoals(int) : void");
        System.out.println("Test #1 - Updates the state of field goals.");
        update_field_Goals_State();

        System.out.println();
        
        System.out.println("setThreePointers(int) : void");
        System.out.println("Test #1 - Updates the state of three pointers.");
        update_three_pointer_State();

        System.out.println();
        
        System.out.println("getPoints() : int");
        System.out.println("Test #1 - Returns the correct number of points.");
        number_Of_Points();

        System.out.println();
        
        System.out.println("toString() : String");
        System.out.println("Test #1 - Returns the correct String representation.");
        return_To_String();
    }

    /**
     * Initialize the name.
     */
    public static void initialize_Name()
    {
        String name = "Clavan";
        int number = 10;
        BasketballPlayer target = new BasketballPlayer(name, number);

        System.out.print("Excepted : ");
        System.out.println(name);

        System.out.print("Actual   : ");
        System.out.println(target.getName());
    }

    /**
     * Initialize the number.
     */
    public static void initialize_Number()
    {
        String name = "Clavan";
        int number = 10;

        BasketballPlayer target = new BasketballPlayer(name, number);

        System.out.print("Excepted : ");
        System.out.println(number);

        System.out.print("Actual   : ");
        System.out.println(target.getNumber());
    }

    /**
     * Initialize the free throws.
     */
    public static void initialize_free_throws()
    {
        String name = "Clavan";
        int number = 10;

        BasketballPlayer target = new BasketballPlayer(name, number);

        System.out.print("Excepted : ");
        System.out.println(0);

        System.out.print("Actual   : ");
        System.out.println(target.getFreeThrows());
    }

    /**
     * Initialize the Field_Goals.
     */
    public static void initialize_Field_Goal()
    {
        String name = "Clavan";
        int number = 10;

        BasketballPlayer target = new BasketballPlayer(name, number);

        System.out.print("Excepted : ");
        System.out.println(0);

        System.out.print("Actual   : ");
        System.out.println(target.getFieldGoals());

    }

    /**
     * Initialize the three pointers.
     */
    public static void initialize_three_pointers()
    {
        String name = "Clavan";
        int number = 10;

        BasketballPlayer target = new BasketballPlayer(name, number);

        System.out.print("Excepted : ");
        System.out.println(0);

        System.out.print("Actual   : ");
        System.out.println(target.getThreePointers());

    }

     /**
     * Updates the state of name.
     */
    public static void update_Name_State()
    {
        String name = "Clavan";
        int number = 10;
        String changeName = "Dsouza";

        BasketballPlayer target = new BasketballPlayer(name, number);

        System.out.print("Excepted : ");
        System.out.println(changeName);

        System.out.print("Actual   : ");
        target.setName(changeName);
        System.out.println(target.getName());

        
    }

    /**
     * Updates the state of number.
     */
    public static void update_Number_State()
    {
        String name = "Clavan";
        int number = 10;
        int changeNumber = 20;

        BasketballPlayer target = new BasketballPlayer(name, number);

        System.out.print("Excepted : ");
        System.out.println(changeNumber);

        System.out.print("Actual   : ");
        target.setNumber(changeNumber);
        System.out.println(target.getNumber());
    }

    /**
     * Updates the state of free throws.
     */
    public static void update_free_throws_State()
    {
        String name = "Clavan";
        int number = 10;
        int freeThrows = 25;

        BasketballPlayer target = new BasketballPlayer(name, number);

        System.out.print("Excepted : ");
        System.out.println(freeThrows);

        System.out.print("Actual   : ");
        target.setFreeThrows(freeThrows);
        System.out.println(target.getFreeThrows());
    }

    /**
     * Updates the state of field goals.
     */
    public static void update_field_Goals_State()
    {
        String name = "Clavan";
        int number = 10;
        int fieldGoals = 9;

        BasketballPlayer target = new BasketballPlayer(name, number);

        System.out.print("Excepted : ");
        System.out.println(fieldGoals);

        System.out.print("Actual   : ");
        target.setFieldGoals(fieldGoals);
        System.out.println(target.getFieldGoals());
    }

    /**
     * Updates the state of three pointers.
     */
    public static void update_three_pointer_State()
    {
        String name = "Clavan";
        int number = 10;
        int threePointers = 12;

        BasketballPlayer target = new BasketballPlayer(name, number);

        System.out.print("Excepted : ");
        System.out.println(threePointers);

        System.out.print("Actual   : ");
        target.setThreePointers(threePointers);
        System.out.println(target.getThreePointers());
    }

    /**
     * Returns the correct number of points.
     */
    public static void number_Of_Points()
    {
        String name = "Clavan";
        int number = 10;
        int freeThrows = 10;
        int fieldGoals = 5;
        int threePointers = 11;

        BasketballPlayer target = new BasketballPlayer(name, number);
        target.setFreeThrows(freeThrows);
        target.setFieldGoals(fieldGoals);
        target.setThreePointers(threePointers);

        System.out.print("Excepted : ");
        int exceptedResult = (freeThrows * 1) + (fieldGoals * 2) + (threePointers * 3);
        System.out.println(exceptedResult);

        System.out.print("Actual   : ");
        System.out.println(target.getPoints());
    }

    /**
     * Updates the state of Assists.
     */
    public static void return_To_String()
    {
        String name = "Clavan";
        int number = 10;
        int freeThrows = 10;
        int fieldGoals = 5;
        int threePointers = 11;

        BasketballPlayer target = new BasketballPlayer(name, number);
        target.setFreeThrows(freeThrows);
        target.setFieldGoals(fieldGoals);
        target.setThreePointers(threePointers);

        System.out.print(target);
    }
    
}
