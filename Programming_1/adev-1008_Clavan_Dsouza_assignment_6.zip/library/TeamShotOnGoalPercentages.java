/*
 * Name: Clavan Dsouza
 * Program: Business Information Technology
 * Course: ADEV-1008 (234101) Programming 1
 * Created: 2023-03-27
 * Updated: 2023-03-30
 */

import java.util.Arrays;

/**
 * Program to encapsulating the concept of a team’s percentages for shots on goal.
 * 
 * @author Clavan Dsouza
 * @version 1.0
 */
public class TeamShotOnGoalPercentages
{
    private double[] percentages;
    
    /**
     * Initializes a new instance of the TeamShotOnGoalPercentages class with the specified number of players.
     * 
     * @param numberOfPlayers The number of players on the team.
     */
    TeamShotOnGoalPercentages(int numberOfPlayers)
    {
       percentages = new double[numberOfPlayers];
    }

    /**
     * Initializes a new instance of the TeamShotOnGoalPercentages class with the specified player’s shot on goal percentages.
     * 
     * @param percentages The shot on goal percentages for each player on the team.
     */
    TeamShotOnGoalPercentages(double[] percentages)
    {
        this.percentages = percentages;
    }

    /**
     * Returns a copy of the specified array.
     * 
     * @param percentagesToCopy The array of percentage values to be copied.
     * @return Returns a copy of the specified array.
     */
    private double[] copyPercentages(double[] percentagesToCopy)
    {
        double[] percentagesCopy = new double[percentagesToCopy.length];           //creating a new array.

        for(int percentagesIndex = 0; percentagesIndex < percentagesToCopy.length; percentagesIndex++)     //for getting one array element at a time.
        {
            percentagesCopy[percentagesIndex] = percentagesToCopy[percentagesIndex];        //then assigning each element to the new array.
        }

        return percentagesCopy;
    }

    /**
     * Returns a copy of the shot on goal percentages.
     * 
     * @return Returns a copy of the shot on goal percentages.
     */
    public double[] getPercentages() 
    {
        return copyPercentages(percentages);
    }
    

    /**
     * Sets the team’s percentages.
     * 
     * @param percentages The shot on goal percentages for each player on the team.
     */
    public void setPercentages(double[] percentages) 
    {
        this.percentages = percentages;
    }


    /**
     * Returns a new array containing the values of the percentages array sorted in descending order.
     * 
     * @return Returns a new array containing the values of the percentages array sorted in descending order.
     */
    public double[] getSortedPercentages()
    {
        double[] sortedPercentages = copyPercentages(percentages);      //getting the array elements using the copyPercentages method.
        
        for(int sortedPercentagesIndex = 0; sortedPercentagesIndex < sortedPercentages.length; sortedPercentagesIndex++)    //number of times the loop will repeat.
        {                                                                                                                   
            for(int element = 0; element < (sortedPercentages.length - sortedPercentagesIndex - 1); element++)
            {
                if(sortedPercentages[element + 1] > sortedPercentages[element])     //checking a element if it is greater than the next element.
                {
                    Double temporary = sortedPercentages[element];                      //copying the first element into another variable(temporary).
                    sortedPercentages[element] = sortedPercentages[element + 1];     //copy the second element into the first element space.
                    sortedPercentages[element + 1] = temporary;                      //then copy the element of temporary variable into the second element. 
                }
            }
        }
        return sortedPercentages;       
    }

    /**
     * Returns the value of the player with the lowest percentage in the specified array.
     * 
     * @param percentages The percentages for each player a team.
     * @return Returns the value of the player with the lowest percentage in the specified array.
     */
    public double getLowestPercentages(double[] percentages)
    {
        return getSortedPercentages()[percentages.length - 1];  //used the sort method(descending) and got the last element of the sorted array.
    }

    /**
     * Returns the mean average of percentages for the top players on the team. 
     * 
     * @return Returns the mean average of percentages for the top players on the team. 
     */
    public double getAverageOfTopPlayers()
    {
        double[] allThePlayers = getSortedPercentages();  //gets the percentages of all the players
        int numberOfTopPlayers = allThePlayers.length >= 5 ? 5 : allThePlayers.length;    //gets all the players if not more than five. 
        double sum = 0;

        for (int i = 0; i < numberOfTopPlayers; i++) 
        {
            sum += allThePlayers[i]; 
        }
        return sum / numberOfTopPlayers;
    }

    /**
     * Returns the String representation of the class.
     * 
     * @return Returns the String representation of the class.
     */
    public String toString()
    {
        String hyphenMinus = "----------------------\n";    //This repeats multiple lines.

        StringBuilder builder = new StringBuilder(hyphenMinus);
        builder.append("Player \t\t SOG%\n");
        builder.append(hyphenMinus);

        for(int i = 0; i < percentages.length; i++) 
        {
            builder.append(String.format("%d \t\t %.6f\n", i + 1, percentages[i]));
        }

        builder.append(hyphenMinus);

        return builder.toString();
    }
}
