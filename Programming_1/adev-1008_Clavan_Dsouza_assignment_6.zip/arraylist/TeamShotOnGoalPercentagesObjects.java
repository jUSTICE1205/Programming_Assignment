/*
 * Name: Clavan Dsouza
 * Program: Business Information Technology
 * Course: ADEV-1008 (234101) Programming 1
 * Created: 2023-04-02
 * Updated: 2023-04-02
 */

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 * Program to store three TeamShotOnGoalPercentages objects. 
 * Each element in the ArrayList represents a team of players. 
 * 
 * @author Clavan Dsouza
 * @version 1.0
 */

class TeamShotOnGoalPercentagesObjects
{
    public static void main(String[] args) 
    {      
        Scanner keyboardInput = new Scanner(System.in);
        Random randomGenerator = new Random();

        ArrayList<TeamShotOnGoalPercentages> allTheTeams = new ArrayList<TeamShotOnGoalPercentages>();

        System.out.println("Enter the number of players per team: ");
        String playerNumber = keyboardInput.nextLine();
        int numberOfPlayers = Integer.parseInt(playerNumber);

        //creating three teams
        for(int team = 0; team < 3; team++)
        {
            double[] teamPercentages = new double[numberOfPlayers];

            for(int percentage = 0; percentage < numberOfPlayers; percentage++)
            {
                teamPercentages[percentage] = randomGenerator.nextInt(99) / 100.0;
            }

            TeamShotOnGoalPercentages eachTeam = new TeamShotOnGoalPercentages(teamPercentages);
            allTheTeams.add(eachTeam);
        }

        int teamNumber = 1;
        for (TeamShotOnGoalPercentages teamShotOnGoalPercentages : allTheTeams) 
        {
            System.out.printf("Team %d\n", teamNumber);
            System.out.println(teamShotOnGoalPercentages);
            teamNumber++;
        }

        System.out.println("LAST ELEMENT BEFORE REMOVE:");
        System.out.println(allTheTeams.get(allTheTeams.size() - 1));

        allTheTeams.remove(allTheTeams.size() - 1);
        System.out.println("LAST ELEMENT AFTER REMOVE:");
        System.out.println(allTheTeams.get(allTheTeams.size() - 1));

    }
}