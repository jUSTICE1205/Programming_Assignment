import javax.xml.transform.Source;

/*
 * Name: Clavan Dsouza
 * Program: Business Information Technology
 * Course: ADEV-1008 (234101) Programming 1
 * Created: 2023-03-02
 * Updated: 2023-03-02
 */

/**
 * Program to test all the methods in the TeamShotOnGoalPercentages.
 *
 * @author Clavan Dsouza
 * @version 1.0
 */
public class TeamShotOnGoalPercentagesTests
{
    public static void main(String[] args) 
    {
        System.out.println("TeamShotOnGoalPercentages(int)");
		System.out.println("Test #1 - Initialize the percentages array without Data.");
        initialize_Array_Without_Data();

        System.out.println("\n");      //lines spaces

        System.out.println("TeamShotOnGoalPercentages(double[])");
        System.out.println("Test #1 - Initialize percentages array with data.");
        initialize_Array_With_Data();

        System.out.println("\n");      //blank lines 

        System.out.println("getPercentages() : double[]");
        System.out.println("Test #1 - Returns a copy of the array used to initialize the object.");
        copy_Of_Array();

        System.out.println("\n");      //blank lines 

        System.out.println("setPercentages(double[]) : void");
        System.out.println("Test #1 - Updates the state of the percentages.");
        update_State_Percentage();  
        
        System.out.println("\n");      //blank lines 

        System.out.println("getSortedPercentages() : double[]");
        System.out.println("Test #1 - Returns a copy of the percentages array sorted in descending order.");
        sort_The_Array();

        System.out.println("\n");      //blank lines 

        System.out.println("getLowestPercentage() : double");
        System.out.println("Test #1 -Returns the correct lowest percentage value.");
        return_Lowest_Value();

        System.out.println("\n");      //blank lines 

        System.out.println("getAverageOfTopPlayers() : double");
        System.out.println("Test #1 -Returns the correct average of the top five players where the number of players is greater than 5.");
        return_Average_of_five_or_more();

        System.out.println("\n");      //blank lines 

        System.out.println("getAverageOfTopPlayers() : double");
        System.out.println("Test #2 -Returns the correct average of the top five players where the number of players is less than 5.");
        return_Average_of_less_than_five();

        System.out.println("\n");

        System.out.println("toString() : String");
        System.out.println("Test #1 -Returns the correct String representation.");
        return_String();

    }

    /**
     * Initialize the percentages array without Data.
     */
    public static void initialize_Array_Without_Data()
    {
        TeamShotOnGoalPercentages target = new TeamShotOnGoalPercentages(4);

        double[] percentages = target.getPercentages();

        //Excepted
        System.out.print("Excepted : ");
        System.out.println("[0, 0, 0, 0]");

        //Actual
        System.out.print("Actual   : ");
        System.out.print("[");
        for(int percentageIndex = 0; percentageIndex < percentages.length; percentageIndex++)
        {
            System.out.printf("%.01f%s ",
                              percentages[percentageIndex],
                              percentageIndex != percentages.length - 1 ? "," : "]");   //ternary operator for comma or fullstop.
        }
    }

    /**
     * Initialize percentages array with data.
     */
    public static void initialize_Array_With_Data()
    {
        double[] percentagesToInitial = {7.67, 4.56, 7.8, 9.0};
        TeamShotOnGoalPercentages target = new TeamShotOnGoalPercentages(percentagesToInitial);

        //Excepted
        System.out.print("Excepted : ");
        System.out.print("[");
        for(int percentageInitalIndex = 0; percentageInitalIndex < percentagesToInitial.length; percentageInitalIndex++)
        {
            System.out.printf("%.2f%s ",
                              percentagesToInitial[percentageInitalIndex],
                              percentageInitalIndex != percentagesToInitial.length - 1 ? "," : "]");
        }

        System.out.println(); //linespace
         
        //Actual
        System.out.print("Actual   : ");
        System.out.print("[");
        double[] getPercentageArray = target.getPercentages();
        for(int getPercentageIndex = 0; getPercentageIndex < getPercentageArray.length; getPercentageIndex++)
        {
            System.out.printf("%.2f%s ",
                              getPercentageArray[getPercentageIndex],
                              getPercentageIndex != getPercentageArray.length - 1 ? "," : "]");
        }
    }

    /**
     * Returns a copy of the array used to initialize the object.
     */
    public static void copy_Of_Array()
    {
        double[] percentagesToInitial = {8.97, 6.9, 17.9, 10.0};
        TeamShotOnGoalPercentages target = new TeamShotOnGoalPercentages(percentagesToInitial);

        //Excepted
        System.out.print("Excepted : ");
        System.out.print("Other than ");
        System.out.println(percentagesToInitial.hashCode());

        //Actual
        System.out.print("Actual   : ");
        double[] copyOfPercentageArray = target.getPercentages();
        System.out.println(copyOfPercentageArray.hashCode());
    }

    /**
     * Updates the state of the percentages.
     */
    public static void update_State_Percentage()
    {
        double[] percentagesOriginal = {8.97, 6.9, 17.9, 10.0};
        TeamShotOnGoalPercentages target = new TeamShotOnGoalPercentages(percentagesOriginal);
        double[] newPercentagesArray = {8.6, 1.908, 6.45, 8.67};    //new values for array.
        
        //Excepted
        System.out.print("Excepted : ");
        System.out.print("[");
        for(int newPercentageIndex = 0; newPercentageIndex < newPercentagesArray.length; newPercentageIndex++)
        {
            System.out.printf("%.2f%s ",
                              newPercentagesArray[newPercentageIndex],
                              newPercentageIndex != newPercentagesArray.length - 1 ? "," : "]");
        }

        System.out.println(); //linespace

        //Actual
        target.setPercentages(newPercentagesArray);
        double[] updatedPercentages = target.getPercentages();

        System.out.print("Actual   : ");
        System.out.print("[");
        for(int updatePercentageIndex = 0; updatePercentageIndex < updatedPercentages.length; updatePercentageIndex++)
        {
            System.out.printf("%.2f%s ",
                              updatedPercentages[updatePercentageIndex],
                              updatePercentageIndex != updatedPercentages.length - 1 ? "," : "]");
        }
    }

    /**
     * Returns a copy of the percentages array sorted in descending order.
     */
    public static void sort_The_Array()
    {
        double[] arrayToSort = {7.67, 4.56, 7.8, 9.0};
        TeamShotOnGoalPercentages target = new TeamShotOnGoalPercentages(arrayToSort);

        //Excepted
        System.out.print("Excepted : ");
        System.out.println("[9.00, 7.80, 7.67, 4.56]");     //directly written.

        //Actual
        double[] updatedPercentages = target.getSortedPercentages();

        System.out.print("Actual   : ");
        System.out.print("[");
        for(int updatePercentageIndex = 0; updatePercentageIndex < updatedPercentages.length; updatePercentageIndex++)
        {
            System.out.printf("%.2f%s ",
                              updatedPercentages[updatePercentageIndex],
                              updatePercentageIndex != updatedPercentages.length - 1 ? "," : "]");
        }
    }

    /**
     * Returns the correct lowest percentage value.
     */
    public static void return_Lowest_Value()
    {
        double[] percentageArray = {6.97, 48.6, 19.4, 1.80, 45.89, 20.01};
        TeamShotOnGoalPercentages target = new TeamShotOnGoalPercentages(percentageArray);

        //Excepted
        System.out.print("Excepted : ");
        System.out.println(" 1.80");

        //Actual
        System.out.print("Actual   : ");
        System.out.printf(" %.2f\n", target.getLowestPercentages(percentageArray));

    }

    /**
     * Returns the correct average of the top five players where the number of players is greater than 5.
     */
    public static void return_Average_of_five_or_more()
    {
        double[] percentageArray = {6.97, 48.6, 19.4, 1.80, 45.89, 20.01};
        TeamShotOnGoalPercentages target = new TeamShotOnGoalPercentages(percentageArray);

        //Excepted
        System.out.print("Excepted : ");
        System.out.println(" 28.17");

        //Actual
        System.out.print("Actual   : ");
        System.out.printf(" %.2f",target.getAverageOfTopPlayers());

    }

    /**
     * Returns the correct average of the top five players where the number of players is less than 5.
     */
    public static void return_Average_of_less_than_five()
    {
        double[] percentageArray = {19.4, 1.80};
        TeamShotOnGoalPercentages target = new TeamShotOnGoalPercentages(percentageArray);

        //Excepted
        System.out.print("Excepted : ");
        System.out.println(" 10.60");

        //Actual
        System.out.print("Actual   : ");
        System.out.printf(" %.2f",target.getAverageOfTopPlayers());
    }

    /**
     * Returns the correct String representation.
     */
    public static void return_String()
    {
        double[] percentageArray = {0.410000, 0.330000, 0.980000, 0.770000, 0.100000};
        TeamShotOnGoalPercentages target = new TeamShotOnGoalPercentages(percentageArray);

        //Excepted
        System.out.println("Excepted :");
        System.out.println("'--------------------");
        System.out.println(" Player        SOG%");
        System.out.println(" --------------------");
        System.out.println(" 1             0.410000");
        System.out.println(" 2             0.330000");
        System.out.println(" 3             0.980000");
        System.out.println(" 4             0.770000");
        System.out.println(" 5             0.100000'");

        System.out.println(); //linespace

        //Actual
        System.out.println("Actual : ");
        System.out.println(target);
    }
}