/*
* Name: Clavan Dsouza
* Program: Business Information Technology
* Course: ADEV-1008 (234101) Programming 1
* Created: 2023-03-05
* Updated: 2023-03-05
*/
import java.util.Scanner;
/*
* program to calculate the area of the room using length and width
* @author Clavan Dsouza
* @version 1.0.0
*/

public class AreaOfRoom
{
    public static int getValues( int value, String promptText)
    {
        do
        {
            System.out.printf("%s",promptText);
            Scanner input = new Scanner(System.in);
            value = input.nextInt();
        }while(value < 0);
        return value;
    }

    public static int areaOfRoom(int length, int width) 
    {
        int area = length* width;
        return area;
    }

    public static void main(String[] args)
    { 
        int length = 0,
            width = 0,
            area = 0; 
        boolean flag = true;

        while(flag) {
            length = getValues(length, "Enter the length of the room: ");
            if (length == 0) 
            {  
                flag = false;
            }
            else 
            {
                width = getValues(width, "Enter the width of the room: ");
                if (width == 0) 
                {                
                    area = areaOfRoom(length, length);
                }
                else
                {
                    area = areaOfRoom(length, width);
                }

                
                System.out.printf("The area of the room is %d.\n\n",area);
            }
             
            
        }  
    }    
}
