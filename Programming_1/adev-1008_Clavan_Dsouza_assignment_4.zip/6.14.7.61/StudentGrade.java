/*
* Name: Clavan Dsouza
* Program: Business Information Technology
* Course: ADEV-1008 (234101) Programming 1
* Created: 2023-03-05
* Updated: 2023-03-05
*/
import java.util.Scanner;
/*
* program to enter the grade of ten student and calculate the highest,lowest and average grade
* @author Clavan Dsouza
* @version 1.0.0
*/

import java.util.Scanner;

public class StudentGrade
{
    public static void main(String[] args) 
    {
        Scanner scanner = new Scanner(System.in);
        int lowestGrade= 100;
        int highestGrade = 0;
        int totalGrade = 0;
        for(int i=1; i<=10; i++) 
        {
            System.out.printf("Enter grade for student %d: ",i);
            int grade = scanner.nextInt();

            if(grade>100 || grade<0) 
            {
                do{
                System.out.printf("Invalid grade. Enter again: ");
                grade = scanner.nextInt();
                }while(grade>100 || grade<0);
            }
            if (grade > highestGrade) 
            {
                highestGrade = grade;
            }
            if (grade < lowestGrade) 
            {
                lowestGrade = grade;
            }

            totalGrade += grade;

        }
        double averageGrade = (double)totalGrade/10;
        System.out.printf("The lowest grade is %d.\n",lowestGrade);
        System.out.printf("The highest grade is %d.\n",highestGrade);
        System.out.printf("The average grade is %.2f.", averageGrade);
    }

}