/*
* Name: Clavan Dsouza
* Program: Business Information Technology
* Course: ADEV-1008 (234101) Programming 1
* Created: 2023-03-05
* Updated: 2023-03-05
*/
import java.util.Scanner;
/*
* program to check whether the entered string is palindrome or not.
* @author Clavan Dsouza
* @version 1.0.0
*/


public class Palindrome 
{
    public static void main(String[] args) 
    {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a sentence: ");
        String sentence = scanner.nextLine().toLowerCase();

        String lettersOnly = "";
        for (int i = 0; i < sentence.length(); i++) 
        {
            char character = sentence.charAt(i);
            if (character >= 'a' && character <= 'z') 
            {
                lettersOnly += character;
            }
        }
        
        boolean checkPalindrome = true;
        for (int i = 0; i < lettersOnly.length(); i++) 
        {
            if (lettersOnly.charAt(i) != lettersOnly.charAt(lettersOnly.length() - i - 1)) 
            {
                checkPalindrome = false;
                i = lettersOnly.length();
            }
        }
        if (checkPalindrome) 
        {
            System.out.println("The sentence is a palindrome!");
        } else 
        {
            System.out.println("The sentence is not a palindrome.");
        }
        scanner.close();
    }
}

