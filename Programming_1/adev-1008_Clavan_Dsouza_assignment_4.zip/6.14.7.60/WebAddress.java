/*
* Name: Clavan Dsouza
* Program: Business Information Technology
* Course: ADEV-1008 (234101) Programming 1
* Created: 2023-03-05
* Updated: 2023-03-05
*/
import java.util.Scanner;
/*
* program to count the commercial address entered by the User.
* @author Clavan Dsouza
* @version 1.0.0
*/



public class WebAddress 
{
    public static void main(String[] args) 
    {
        Scanner scanner = new Scanner(System.in);
        String webAddress;
        int noOfCommercialAddress = 0;
        System.out.println("<Type \"stop\" to end the program>");
        do {
            System.out.print("Enter a web address: ");
            webAddress = scanner.nextLine().toLowerCase();
            if(webAddress.endsWith(".com")) 
            {
                noOfCommercialAddress += 1;
            }
        } while (!webAddress.equals("stop"));
        System.out.printf("The number of commercial websites entered %d.",noOfCommercialAddress);
        scanner.close();
    }
}
