/*
 * Name: Clavan Dsouza
 * Program: Business Information Technology
 * Course: ADEV-1008 (234101) Programming 1
 * Created: 2023-03-18
 * Updated: 2023-03-18
 */

/**
 * Program to Convert the given temperature to celsius and check for the consistency.
 *
 * @author Clavan Dsouza
 * @version 1.0
 */
public class WeatherForecast
{
    private int temperature; 
    private SkyCondition skyCondition;
    public static final int CONSISTENCY_FACTOR = 32;
	public static final int MINIMUM_TEMPERATURE = -50;
	public static final int MAXIMUM_TEMPERATURE = 150;

    /**
     * Initializes an instance of the WeatherForecast class with a specified temperature and sky condition of sunny.
     * 
     * @param temperature The Temperature of the Weather.
     */
    public WeatherForecast(int temperature)
	{
		this.skyCondition = SkyCondition.SUNNY;

		if(temperature < MINIMUM_TEMPERATURE || temperature > MAXIMUM_TEMPERATURE)
		{
			this.temperature = 0;
		}
		else
		{
			this.temperature = temperature;
		}
	}

    /**
     * Initializes an instance of the WeatherForecast class with a specified temperature of 70 and sky condition of sunny.
     * 
     */
    public WeatherForecast()
    {
        this(70);
    }

    /**
     * Returns the weather forecast's temperature.
     * 
     * @return Returns the weather forecast's temperature.
     */
    public int getTemperature() 
    {
        return temperature;
    }

    /**
     * Sets the weather forecast's temperature.
     * 
     * @param temperature The temperature of the weather forecast.
     */
    public void setTemperature(int temperature) 
    {
        if(temperature < MINIMUM_TEMPERATURE || temperature > MAXIMUM_TEMPERATURE)
		{
			this.temperature = 0;
		}
		else
		{
			this.temperature = temperature;
		}
    }

    /**
     * Returns the weather forecast's sky condition.
     * 
     * @return Returns the weather forecast's sky condition.
     */
    public SkyCondition getSkyCondition() 
    {
        return skyCondition;
    }

    /**
     * Sets the weather forecast's sky condition.
     * 
     * @param skyCondition The sky condition of the weather forecast.
     */
    public void setSkyCondition(SkyCondition skyCondition) 
    {
        this.skyCondition = skyCondition;
    }

    /**
     * Returns the celsius temperature of the specified Fahrenheit temperature.
     * 
     * @param fahrenheit A temperature in Fahrenheit.
     * @return returns the celsius tempreature of the specified Fahrenheit temperature.
     */
	public static int toCelsius(int fahrenheit)
	{
		return (fahrenheit - CONSISTENCY_FACTOR) * 5 / 9 ;
	}

    /**
     * Returns true when the weather forecast is consistent, otherwise false.
     * 
     * @return Returns true if the weather forecast is consistent, otherwise returns false.
     */
    public boolean isConsistent()
	{
		if(temperature > CONSISTENCY_FACTOR && skyCondition == skyCondition.SNOWY || temperature < CONSISTENCY_FACTOR && skyCondition == skyCondition.RAINY)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

    /**
     * Returns a String representation of the weather forecast.
     *
     * @return a String representation of the weather forecast.
     */
    public String toString()
	{
		String template = "Current condition: %d and " + this.skyCondition ;
		return String.format(template, this.temperature);
	}
}