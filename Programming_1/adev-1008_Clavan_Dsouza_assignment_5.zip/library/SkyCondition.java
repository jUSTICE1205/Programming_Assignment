/*
 * Name: Clavan Dsouza
 * Program: Business Information Technology
 * Course: ADEV-1008 (234101) Programming 1
 * Created: 2023-03-18
 * Updated: 2023-03-18
 */

/**
 * Represents the condition of the sky.
 *
 * @author Clavan Dsouza
 * @version 1.0
 */
public enum SkyCondition
{
    SUNNY,
    SNOWY,
    CLOUDY,
    RAINY
}