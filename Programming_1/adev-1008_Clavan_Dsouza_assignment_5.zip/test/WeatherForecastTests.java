/*
 * Name: Clavan Dsouza
 * Program: Business Information Technology
 * Course: ADEV-1008 (234101) Programming 1
 * Created: 2023-03-18
 * Updated: 2023-03-18
 */

/**
 * Program to test all the methods in the WeatherForecast.
 *
 * @author Clavan Dsouza
 * @version 1.0
 */
public class WeatherForecastTests
{
	public static void main(String[] args)
	{
		System.out.println("Weatherforecast(int)");
		System.out.println("Test #1 - Initialize the temperature with a value below the minimum.");
		constructor1_initialize_below_Minimum();

		System.out.println("Test #2 - Initialize the temperature to the minimum temperature.");
		constructor1_initialize_to_minimum_Temperature();

		System.out.println("Test #3 - Initialize the temperature within the range.");
		constructor1_initializing_within_range();

		System.out.println("Test #4 - Initialize the temperature to the maximum temperature.");
		constructor1_initialize_to_maximum_Temperature();

		System.out.println("Test #5 - Initialize the temperature above the maximum temperature.");
		constructor1_initialize_above_Maximum();

		System.out.println("Test #6 - Initialize the sky condition.");
		constructor1_initialize_skyCondition();

		System.out.println("WeatherForecast()");
		System.out.println("Test #1 - Initialize the temperature.");
		constructor2_initialize_temperature();

		System.out.println("Test #2 - Initialize the sky condition.");
		constructor2_initialize_skyCondition();

		System.out.println("setTemperature(int)");
		System.out.println("Test #1 - Update the state of the temperature with a value below the minimum.");
		setTemperature_UpdatesState_Below_Minimum_Temperature();

		System.out.println("Test #2 - Update the state of the temperature to the minimum temperature.");
		setTemperature_UpdatesState_To_Minimum_Temperature();

		System.out.println("Test #3 - Update the state of the temperature within the range.");
		setTemperature_UpdatesState_Within_Range();

		System.out.println("Test #4 - Update the state of the temperature to the maximum temperature.");
		setTemperature_UpdatesState_To_Maximum_Temperature();

		System.out.println("Test #5 - Update the state of the temperature above the maximum temperature.");
		setTemperature_UpdatesState_To_Above_Temperature();

		System.out.println("setSkyCondition(SkyCondition)");
		System.out.println("Test #1 - Update the state of sky condition.");
		setSkyCondition_updatesState_skyCondition();

		System.out.println("toCelcius(int)");
		System.out.println("Test #1 - Returns the temperature in Celsius.");
		temperature_to_Celsius();

		System.out.println("isConsistent()");
		System.out.println("Test #1 - The temperature is too hot for snow.");
		isConsistent_Temperature_Too_Hot_For_Snow();

		System.out.println("Test #2 - The temperature is cold enough for snow.");
		isConsistent_Temperature_Cold_Enough_For_Snow();

		System.out.println("Test #3 - The temperature is too cold for rain.");
		isConsistent_temperature_Too_Cold_For_Rain();

		System.out.println("Test #4 - The temperature is warm enough for rain.");
		isConsistent_temperature_Warm_Enough_For_Rain();

		System.out.println("toString()");
		System.out.println("Test #1 - Returns the correct String representation.");
		toString_returnsStringRepresentation();
	}

	/**
	 * constructor_1 - WeatherForecast(int)
	 */
	public static void constructor1_initialize_below_Minimum()
	{
		// Setup test data
		int temperature = -60;

		// Act
		WeatherForecast target = new WeatherForecast(temperature);

		// Confirm
		int expected = 0;
		int actual = target.getTemperature();

		System.out.printf("Expected: %d\nActual: %d\n\n", expected, actual);
	}

	/**
	 * constructor_1 = WeatherForecast(int)
	 */
	public static void constructor1_initialize_to_minimum_Temperature()
	{
		//Setup test data
		int temperature = -50;

		//Act
		WeatherForecast target = new WeatherForecast(temperature);

		//Confirm
		int expected = -50;
		int actual = target.getTemperature();

		System.out.printf("Expected: %d\nActual: %d\n\n", expected, actual);
	}

	/**
	 * constructor_1 = WeatherForecast(int)
	 */
	public static void constructor1_initializing_within_range()
	{
		//Setup test data
		int temperature = 25;

		//Act
		WeatherForecast target = new WeatherForecast(temperature);

		//Confirm
		int expected = 25;
		int actual = target.getTemperature();

		System.out.printf("Expected: %d\nActual: %d\n\n", expected, actual);
	}

	/**
	 * constructor_1 = WeatherForecast(int)
	 */
	public static void constructor1_initialize_to_maximum_Temperature()
	{
		//Setup test data
		int temperature = 150;

		//Act
		WeatherForecast target = new WeatherForecast(temperature);

		//Confirm
		int expected = 150;
		int actual = target.getTemperature();

		System.out.printf("Expected: %d\nActual: %d\n\n", expected, actual);
	}

	/**
	 * constructor_1 = WeatherForecast(int)
	 */
	public static void constructor1_initialize_above_Maximum()
	{
		//Setup test data
		int temperature = 160;

		//Act
		WeatherForecast target = new WeatherForecast(temperature);

		//Confirm
		int expected = 0;
		int actual = target.getTemperature();

		System.out.printf("Expected: %d\nActual: %d\n\n", expected, actual);
	}

	/**
	 * constructor_1 = WeatherForecast(int)
	 */
	public static void constructor1_initialize_skyCondition()
	{
		//Setup test data
		int temperature = 30;

		//Act
		WeatherForecast target = new WeatherForecast(temperature);

		//confirm
		String expected = "SUNNY";
		SkyCondition actual = target.getSkyCondition();

		System.out.printf("Expected: %s\nActual: " + actual + "\n\n", expected);
	}

	/**
	 * constructor_2 = WeatherForecast()
	 */
	public static void constructor2_initialize_temperature()
	{
		//Act
		WeatherForecast target = new WeatherForecast();

		//confirm
		int expected = 70;
		int actual = target.getTemperature();

		System.out.printf("Expected: %d\nActual: %d\n\n", expected, actual);
	}

	/**
	 * constructor_2 = WeatherForecast()
	 */
	public static void constructor2_initialize_skyCondition()
	{
		//Act
		WeatherForecast target = new WeatherForecast();

		//Confirm
		SkyCondition expected = SkyCondition.SUNNY;
		SkyCondition actual = target.getSkyCondition();

		System.out.printf("Expected: " + expected + "\nActual: " + actual + "\n\n");
	}

	/**
	 * setTemperature = setTemperature(int)
	 */
	public static void setTemperature_UpdatesState_Below_Minimum_Temperature()
	{
		//Setup test data
		int temperature = 30;

		//Act
		WeatherForecast target = new WeatherForecast(temperature);
		target.setTemperature(-60);

		//Confirm
		int expected = 0;
		int actual = target.getTemperature();

		System.out.printf("Expected: %d\nActual: %d\n\n", expected, actual);
	}

	/**
	 * setTemperature = setTemperature(int)
	 */
	public static void setTemperature_UpdatesState_To_Minimum_Temperature()
	{
		//Setup test data
		int temperature = 30;

		//Act
		WeatherForecast target = new WeatherForecast(temperature);
		target.setTemperature(-50);

		//Confirm
		int expected = -50;
		int actual = target.getTemperature();

		System.out.printf("Expected: %d\nActual: %d\n\n", expected, actual);
	}

	/**
	 * setTemperature = setTemperature(int)
	 */
	public static void setTemperature_UpdatesState_Within_Range()
	{
		//Setup test data
		int temperature = 30;

		//Act
		WeatherForecast target = new WeatherForecast(temperature);
		target.setTemperature(72);

		//Confirm
		int expected = 72;
		int actual = target.getTemperature();

		System.out.printf("Expected: %d\nActual: %d\n\n", expected, actual);
	}

	/**
	 * setTemperature = setTemperature(int)
	 */
	public static void setTemperature_UpdatesState_To_Maximum_Temperature()
	{
		//Setup test data
		int temperature = 30;

		//Act
		WeatherForecast target = new WeatherForecast(temperature);
		target.setTemperature(150);

		//Confirm
		int expected = 150;
		int actual = target.getTemperature();

		System.out.printf("Expected: %d\nActual: %d\n\n", expected, actual);
	}

	/**
	 * setTemperature = setTemperature(int)
	 */
	public static void setTemperature_UpdatesState_To_Above_Temperature()
	{
		//Setup test data
		int temperature = 30;

		//Act
		WeatherForecast target = new WeatherForecast(temperature);
		target.setTemperature(160);

		//Confirm
		int expected = 0;
		int actual = target.getTemperature();

		System.out.printf("Expected: %d\nActual: %d\n\n", expected, actual);
	}

	/**
	 * setSkyCondition = setSkyCondition(SkyCondition)
	 */
	public static void setSkyCondition_updatesState_skyCondition()
	{
		//Setup test data
		WeatherForecast target = new WeatherForecast();

		//Act
		target.setSkyCondition(SkyCondition.CLOUDY);

		//Confirm
		SkyCondition expected = SkyCondition.CLOUDY;
		SkyCondition actual = target.getSkyCondition();

		System.out.printf("Expected: " + expected + "\nActual: " + actual + "\n\n");
	}

	/**
	 * toCelsius(int)
	 */
	public static void temperature_to_Celsius()
	{
		//Setup test data
		int temperatureInFahrenheit = 99;

		//Act
		int temperatureInCelsius = WeatherForecast.toCelsius(temperatureInFahrenheit);

		//Confirm
		int expected = 37;
		int actual = temperatureInCelsius;

		System.out.printf("Expected: %d\nActual: %d\n\n", expected, actual);
	}

	/**
	 * isConsistent()
	 */
	public static void isConsistent_Temperature_Too_Hot_For_Snow()
	{
		//Setup test data
		int temperature = 35;

		//Act
		WeatherForecast target = new WeatherForecast(temperature);
		target.setSkyCondition(SkyCondition.SNOWY);

		//Confirm
		boolean expected = false;
		boolean actual = target.isConsistent();

		System.out.printf("Expected: " + expected + "\nActual: " + actual + "\n\n");
	}

	/**
	 * isConsistent()
	 */
	public static void isConsistent_Temperature_Cold_Enough_For_Snow()
	{
		//Setup test data
		int temperature = 0;
		SkyCondition skyCondition = SkyCondition.SNOWY;

		//Act
		WeatherForecast target = new WeatherForecast(temperature);
		target.setSkyCondition(skyCondition);

		//Confirm
		boolean expected = true;
		boolean actual = target.isConsistent();

		System.out.printf("Expected: " + expected + "\nActual: " + actual + "\n\n");
	}

	/**
	 * isConsistent()
	 */
	public static void isConsistent_temperature_Too_Cold_For_Rain()
	{
		//Setup test data
		int temperature = -10;
		SkyCondition skyCondition = SkyCondition.RAINY;

		//Act
		WeatherForecast target = new WeatherForecast(temperature);
		target.setSkyCondition(skyCondition);

		//Confirm
		boolean expected = false;
		boolean actual = target.isConsistent();

		System.out.printf("Expected: " + expected + "\nActual: " + actual + "\n\n");
	}

	/**
	 * isConsistent()
	 */
	public static void isConsistent_temperature_Warm_Enough_For_Rain()
	{
		//Setup test data
		int temperature = 38;
		SkyCondition skyCondition = SkyCondition.RAINY;

		//Act
		WeatherForecast target = new WeatherForecast(temperature);
		target.setSkyCondition(skyCondition);

		//Confirm
		boolean expected = true;
		boolean actual = target.isConsistent();

		System.out.printf("Expected: " + expected + "\nActual: " + actual + "\n\n");
	}

	/**
	 * toString()
	 */
	public static void toString_returnsStringRepresentation()
	{
		//Setup test data
		int temperature = 38;
		SkyCondition skyCondition = SkyCondition.SUNNY;

		WeatherForecast target = new WeatherForecast(temperature);

		//Act
		String actual = target.toString();

		//Confirm
		String expected = "Current condition: 38 and SUNNY ";

		System.out.printf("Expected: %s\nActual: %s\n\n", expected, actual);
	}
}