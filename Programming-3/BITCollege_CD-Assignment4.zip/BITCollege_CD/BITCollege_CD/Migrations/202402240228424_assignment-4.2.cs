﻿namespace BITCollege_CD.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class assignment42 : DbMigration
    {
        public override void Up()
        {
        }
        
        public override void Down()
        {
        }
    }
}
