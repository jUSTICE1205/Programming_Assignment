﻿namespace BITCollege_CD.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class assignment41 : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.NextUniqueNumbers",
                c => new
                    {
                        NextUniqueNUmberId = c.Int(nullable: false, identity: true),
                        NextAvailableNumber = c.Long(nullable: false),
                        Discriminator = c.String(nullable: false, maxLength: 128),
                    })
                .PrimaryKey(t => t.NextUniqueNUmberId);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.NextUniqueNumbers");
        }
    }
}
