﻿/*
 * Name: Clavan Dsouza
 * Program: Business Information Technology
 * Course: ADEV-3008 Programming 3
 * Created: 09-01-2024
 * Updated: 12-01-2024
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Utility;
using System.Diagnostics;
using System.Data;

namespace BITCollege_CD.Models
{
    /// <summary>
    /// Student Model :- Represents the students table in the database.
    /// </summary>
    /// <summary>
    ///  Student Model - to represent Student table in database.
    /// </summary>
    public class Student
    {
        private BITCollege_CDContext db = new BITCollege_CDContext();

        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int StudentId { get; set; }

        [Required]
        [ForeignKey("GradePointState")]
        public int GradePointStateId { get; set; }

        [ForeignKey("AcademicProgram")]
        public int? AcademicProgramId { get; set; }

        [Display(Name = "Student\nNumber")]
        public long StudentNumber { get; set; }

        [Required]
        [Display(Name = "First\nName")]
        public string FirstName { get; set; }

        [Required]
        [Display(Name = "Last\nName")]
        public string LastName { get; set; }

        [Required]
        public string Address { get; set; }

        [Required]
        public string City { get; set; }

        [Required]
        [RegularExpression("^(N[BLSTU]|[AMN]B|[BQ]C|ON|PE|SK|YT)", ErrorMessage = "Invalid Canadian province code")]
        public string Province { get; set; }

        [Required]
        [Display(Name = "Date")]
        [DisplayFormat(DataFormatString = "{0:d}", ApplyFormatInEditMode = true)]
        public DateTime DateCreated { get; set; }

        [Range(0, 4.5)]
        [DisplayFormat(DataFormatString = "{0:F2}", ApplyFormatInEditMode = true)]
        [Display(Name = "Grade\nPoint\nAverage")]
        public double? GradePointAverage { get; set; }

        [Required]
        [Display(Name = "Fees")]
        [DisplayFormat(DataFormatString = "{0:C}", ApplyFormatInEditMode = true)]
        public double OutstandingFees { get; set; }

        public string Notes { get; set; }

        [Display(Name = "Name")]
        public string FullName
        {
            get
            {
                return String.Format("{0} {1}", FirstName, LastName);
            }
        }

        [Display(Name = "Address")]
        public string FullAddress
        {
            get
            {
                return String.Format("{0} {1}, {2}", Address, City, Province);
            }
        }

        /// <summary>
        /// Changes the account state. Runs until the criteria for the current state is met.
        /// </summary>
        public void ChangeState()
        {
            GradePointState state = db.GradePointStates.Find(this.GradePointStateId);
            int previousState = 0;

            while (previousState != state.GradePointStateId)
            {
                state.StateChangeCheck(this);
                previousState = state.GradePointStateId;
                state = db.GradePointStates.Find(this.GradePointStateId);
            }
        }

        /// <summary>
        /// Sets the next student number
        /// </summary>
        public void SetNextStudentNumber()
        {
            StudentNumber = (long)BusinessRules.StoredProcedures.NextNumber("NextStudent");
            
        }

        //Navigation properties
        public virtual GradePointState GradePointState { get; set; }

        public virtual AcademicProgram AcademicProgram { get; set; }

        public virtual ICollection<Registration> Registration { get; set; }
    }

    /// <summary>
    /// AcademicProgram Model - to represent the AcademicProgrm table in the database.
    /// </summary>
    public class AcademicProgram
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int AcademicProgramId { get; set; }

        [Required]
        [Display(Name = "Program")]
        public string ProgramAcronym { get; set; }

        [Required]
        [Display(Name = "Program\nName")]
        public string Description { get; set; }

        //Navigation properties
        public virtual ICollection<Student> Student { get; set; }

        public virtual ICollection<Course> Course { get; set; }
    }

    /// <summary>
    /// GradePointState Model - to represent the GradePointState table in the database.
    /// </summary>
    public abstract class GradePointState
    {
        protected static BITCollege_CDContext db = new BITCollege_CDContext();

        [Key]
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int GradePointStateId { get; set; }

        [Required]
        [DisplayFormat(DataFormatString = "{0:N2}", ApplyFormatInEditMode = true)]
        [Display(Name = "Lower\nLimit")]
        public double LowerLimit { get; set; }

        [Required]
        [DisplayFormat(DataFormatString = "{0:N2}", ApplyFormatInEditMode = true)]
        [Display(Name = "Upper\nLimit")]
        public double UpperLimit { get; set; }

        [Required]
        [DisplayFormat(DataFormatString = "{0:N2}", ApplyFormatInEditMode = true)]
        [Display(Name = "Tuition\nRate\nFactor")]
        public double TuitionRateFactor { get; set; }

        [Display(Name = "State")]
        public string Description
        {
            get
            {
                return BusinessRules.currentInstanceName(GetType().Name, "State");
            }
        }

        //Navigation property
        public virtual ICollection<Student> Student { get; set; }

        /// <summary>
        /// This a abstract method for the GradePointState.
        /// </summary>
        /// <param name="student">The student who's tuition rate needs to be adjusted</param>
        /// <returns>Returns the update tuition rate</returns>
        public abstract double TuitionRateAdjustment(Student student);

        /// <summary>
        /// This a abstract method for the GradePointState.
        /// </summary>
        /// <param name="student">The student who's state needs to be checked</param>
        public abstract void StateChangeCheck(Student student);

    }

    /// <summary>
    /// SuspendedState Model - to represent the course table in the database.
    /// </summary>
    public class SuspendedState : GradePointState
    {
        private static SuspendedState suspendedState;

        /// <summary>
        /// Initializes the newly created Suspende state Object
        /// </summary>
        private SuspendedState()
        {
            this.UpperLimit = 1.00;
            this.LowerLimit = 0.00;
            this.TuitionRateFactor = 1.1;
        }

        /// <summary>
        /// Gets the instance of the suspended state
        /// </summary>
        /// <returns>Returns the instance of the suspended state</returns>
        public static SuspendedState GetInstance()
        {
            if (suspendedState == null)
            {
                suspendedState = db.SuspendedStates.SingleOrDefault();

                if (suspendedState == null)
                {
                    suspendedState = new SuspendedState();
                    db.SuspendedStates.Add(suspendedState);
                    db.SaveChanges();
                }
            }

            return suspendedState;
        }

        /// <summary>
        /// Adjusts the student's Tution Rate.
        /// </summary>
        /// <param name="student">The student who's tuition rate needs to be adjusted</param>
        /// <returns>Returns the update tuition rate</returns>
        public override double TuitionRateAdjustment(Student student)
        {
            double adjustedrate = TuitionRateFactor;

            if (student.GradePointAverage < 0.75)
            {
                adjustedrate += 0.02;

                if(student.GradePointAverage < 0.50)
                {
                    adjustedrate += 0.03;
                }
            }

            return adjustedrate;
        }

        /// <summary>
        /// Checks the students state change.
        /// </summary>
        /// <param name="student">The student who's state needs to be checked</param>
        public override void StateChangeCheck(Student student)
        {
            if (student.GradePointAverage > UpperLimit)
            {
                student.GradePointStateId = ProbationState.GetInstance().GradePointStateId;
            }
            else
            {
                student.GradePointStateId = SuspendedState.GetInstance().GradePointStateId;
            }
        }
    }

    /// <summary>
    /// ProbationState Model - to represent the ProbationState table in the database.
    /// </summary>
    public class ProbationState : GradePointState
    {
        private static ProbationState probationState;

        /// <summary>
        /// Initializes the newly created Probation state Object
        /// </summary>
        private ProbationState()
        {
            this.UpperLimit = 2.00;
            this.LowerLimit = 1.00;
            this.TuitionRateFactor = 1.075;
        }

        /// <summary>
        /// Gets the instance of the Probation state
        /// </summary>
        /// <returns>Returns the instance of the Probation state</returns>
        public static ProbationState GetInstance()
        {
            if (probationState == null)
            {
                probationState = db.ProbationStates.SingleOrDefault();

                if (probationState == null)
                {
                    probationState = new ProbationState();
                    db.ProbationStates.Add(probationState);
                    db.SaveChanges();
                }
            }

            return probationState;
        }

        /// <summary>
        /// Adjusts the student's Tution Rate.
        /// </summary>
        /// <param name="student">The student who's tuition rate needs to be adjusted</param>
        /// <returns>Returns the update tuition rate</returns>
        public override double TuitionRateAdjustment(Student student)
        {
            double adjustedrate = TuitionRateFactor;

            IQueryable<Registration> studentCourses = db.Registrations.Where(x => x.StudentId == student.StudentId && x.Grade != null);
            int NoOfCompletedCourses = studentCourses.Count();

            if(NoOfCompletedCourses >= 5)
            {
                adjustedrate = 1.035;
            }

            return adjustedrate;
        }

        /// <summary>
        /// Checks the students state change.
        /// </summary>
        /// <param name="student">The student who's state needs to be checked</param>
        public override void StateChangeCheck(Student student)
        {
            if (student.GradePointAverage > UpperLimit)
            {
                student.GradePointStateId = RegularState.GetInstance().GradePointStateId;
            }
            else if ( student.GradePointAverage < LowerLimit)
            {
                student.GradePointStateId = SuspendedState.GetInstance().GradePointStateId;
            }
        }
    }

    /// <summary>
    /// RegularState Model - to represent the RegularState table in the database.
    /// </summary>
    public class RegularState : GradePointState
    {
        private static RegularState regularState;

        /// <summary>
        /// Initializes the newly created Regular state Object
        /// </summary>
        private RegularState()
        {
            this.UpperLimit = 3.70;
            this.LowerLimit = 2.00;
            this.TuitionRateFactor = 1.0;
        }

        /// <summary>
        /// Gets the instance of the Regular state
        /// </summary>
        /// <returns>Returns the instance of the Regular state</returns>
        public static RegularState GetInstance()
        {
            if (regularState == null)
            {
                regularState = db.RegularStates.SingleOrDefault();

                if (regularState == null)
                {
                    regularState = new RegularState();
                    db.RegularStates.Add(regularState);
                    db.SaveChanges();
                }
            }

            return regularState;
        }

        /// <summary>
        /// Adjusts the student's Tution Rate.
        /// </summary>
        /// <param name="student">The student who's tuition rate needs to be adjusted</param>
        /// <returns>Returns the update tuition rate</returns>
        public override double TuitionRateAdjustment(Student student)
        {
            return TuitionRateFactor;
        }

        /// <summary>
        /// Checks the students state change.
        /// </summary>
        /// <param name="student">The student who's state needs to be checked</param>
        public override void StateChangeCheck(Student student)
        {
            if (student.GradePointAverage > UpperLimit)
            {
                student.GradePointStateId = HonoursState.GetInstance().GradePointStateId;
            }
            else if (student.GradePointAverage < LowerLimit)
            {
                student.GradePointStateId = ProbationState.GetInstance().GradePointStateId;
            }
        }
    }

    /// <summary>
    /// HonoursState Model - to represent the HonoursState table in the database.
    /// </summary>
    public class HonoursState : GradePointState
    {
        private static HonoursState honoursState;

        /// <summary>
        /// Initializes the newly created honours state Object
        /// </summary>
        private HonoursState()
        {
            this.LowerLimit = 3.70;
            this.UpperLimit = 4.50;
            this.TuitionRateFactor = 0.9;
        }

        /// <summary>
        /// Gets the instance of the honours state
        /// </summary>
        /// <returns>Returns the instance of the honours state</returns>
        public static HonoursState GetInstance()
        {
            if (honoursState == null)
            {
                honoursState = db.HonoursStates.SingleOrDefault();

                if (honoursState == null)
                {
                    honoursState = new HonoursState();
                    db.HonoursStates.Add(honoursState);
                    db.SaveChanges();
                }
            }

            return honoursState;
        }

        /// <summary>
        /// Adjusts the student's Tution Rate.
        /// </summary>
        /// <param name="student">The student who's tuition rate needs to be adjusted</param>
        /// <returns>Returns the update tuition rate</returns>
        public override double TuitionRateAdjustment(Student student)
        {
            double adjustedrate = TuitionRateFactor;

            IQueryable<Registration> studentCourses = db.Registrations.Where(x => x.StudentId == student.StudentId && x.Grade != null);
            int NoOfCompletedCourses = studentCourses.Count();

            if (NoOfCompletedCourses >= 5)
            {
                adjustedrate -= 0.05;
            }

            if(student.GradePointAverage > 4.25)
            {
                adjustedrate -= 0.02;
            }

            return adjustedrate;
        }

        /// <summary>
        /// Checks the students state change.
        /// </summary>
        /// <param name="student">The student who's state needs to be checked</param>
        public override void StateChangeCheck(Student student)
        {
            if (student.GradePointAverage < LowerLimit)
            {
                student.GradePointStateId = RegularState.GetInstance().GradePointStateId;
            }
        }
    }

    /// <summary>
    /// Course Model - to represent the Course table in the database.
    /// </summary>
    public abstract class Course
    {
        [Key]
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int CourseId { get; set; }

        [ForeignKey("AcademicProgram")]
        public int? AcademicProgramId { get; set; }

        [Display(Name = "Course\nNumber")]
        public string CourseNumber { get; set; }

        [Required]
        public string Title { get; set; }

        [Required]
        [DisplayFormat(DataFormatString = "{0:N}", ApplyFormatInEditMode = true)]
        [Display(Name = "Credit\nHours")]
        public double CreditHours { get; set; }

        [Required]
        [DisplayFormat(DataFormatString = "{0:C2}", ApplyFormatInEditMode = true)]
        [Display(Name = "Tuition")]
        public double TuitionAmount { get; set; }

        [Display(Name = "Course\nType")]
        public string CourseType
        {
            get
            {
                return BusinessRules.currentInstanceName(GetType().Name, "Course");
            }
        }

        public string Notes { get; set; }

        /// <summary>
        /// Sets the next course number
        /// </summary>
        public abstract void SetNextCourseNumber();

        //Navigation properties
        public virtual ICollection<Registration> Registrations { get; set; }

        public virtual AcademicProgram AcademicProgram { get; set; }
    }

    /// <summary>
    /// GradedCourse Model - inherits Course class 
    /// </summary>
    public class GradedCourse : Course
    {
        [Required]
        [Display(Name = "Assignments")]
        [DisplayFormat(DataFormatString = "{0:p}", ApplyFormatInEditMode = true)]
        public double AssignmentWeight { get; set; }

        [Required]
        [Display(Name = "Exams")]
        [DisplayFormat(DataFormatString = "{0:p}", ApplyFormatInEditMode = true)]
        public double ExamWeight { get; set; }

        /// <summary>
        /// Sets the next course number
        /// </summary>
        public override void SetNextCourseNumber()
        {
            CourseNumber = string.Concat("G-", BusinessRules.StoredProcedures.NextNumber("NextGradedCourse"));
        }
    }

    /// <summary>
    /// MasteryCourse Model - inherits Course class 
    /// </summary>
    public class MasteryCourse : Course
    {
        [Required]
        [Display(Name = "Maximum\nAttempts")]
        public int MaximumAttempts { get; set; }

        /// <summary>
        /// Sets the next course number
        /// </summary>
        public override void SetNextCourseNumber()
        {
            CourseNumber = string.Concat("M-", BusinessRules.StoredProcedures.NextNumber("NextMasteryCourse"));
        }
    }

    /// <summary>
    /// AuditCourse Model - inherits Course class 
    /// </summary>
    public class AuditCourse : Course
    {
        /// <summary>
        /// Sets the next course number
        /// </summary>
        public override void SetNextCourseNumber()
        {
            CourseNumber = string.Concat("A-", BusinessRules.StoredProcedures.NextNumber("NextAuditCourse"));
        }
    }

    /// <summary>
    /// Registration Model - to represent the course table in the database.
    /// </summary>
    public class Registration
    {
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int RegistrationId { get; set; }

        [Required]
        [ForeignKey("Student")]
        public int StudentId { get; set; }

        [Required]
        [ForeignKey("Course")]
        public int CourseId { get; set; }

        [Display(Name = "Registration\nNumber")]
        public long RegistrationNumber { get; set; }

        [Required]
        [Display(Name = "Date")]
        [DisplayFormat(DataFormatString = "{0:d}", ApplyFormatInEditMode = true)]
        public DateTime RegistrationDate { get; set; }

        [DisplayFormat(NullDisplayText = "Ungraded")]
        [Range(0, 1)]
        public double? Grade { get; set; }

        public string Notes { get; set; }

        /// <summary>
        /// Sets the next registration number
        /// </summary>
        public void SetNextRegistrationNumber()
        {
            RegistrationNumber = (long) BusinessRules.StoredProcedures.NextNumber("NextRegistration");
        }

        //Navigation properties
        public virtual Student Student { get; set; }

        public virtual Course Course { get; set; }
    }

    /// <summary>
    /// This models represent the next unique number
    /// </summary>
    public abstract class NextUniqueNumber 
    {
        protected static BITCollege_CDContext Db = new BITCollege_CDContext();
        /// <summary>
        /// gets and sets the next unique number
        /// </summary>
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        [Key]
        [Required]
        public int NextUniqueNUmberId { get; set; }

        /// <summary>
        /// gets and sets the next available number
        /// </summary>
        public long NextAvailableNumber { get; set; }
    }

    /// <summary>
    /// This models represents the unique number for student
    /// </summary>
    public class NextStudent : NextUniqueNumber
    {
        private static NextStudent nextStudent;

        /// <summary>
        /// Initailizes the NextStudent
        /// </summary>
        private NextStudent()
        {
            this.NextAvailableNumber = 20000000;
        }

        public static NextStudent GetInstance()
        {
            if (nextStudent == null)
            {
                nextStudent = Db.NextStudents.SingleOrDefault();

                if(nextStudent == null)
                {
                    nextStudent = new NextStudent();
                    Db.NextStudents.Add(nextStudent);
                    Db.SaveChanges();
                }
            }
            return nextStudent;
        }
    }

    /// <summary>
    /// This models represents the unique number for student
    /// </summary>
    public class NextGradedCourse : NextUniqueNumber
    {
        private static NextGradedCourse nextGradedCourse;

        /// <summary>
        /// Initailizes the NextGradedCourse
        /// </summary>
        private NextGradedCourse()
        {
            this.NextAvailableNumber = 200000;
        }

        public static NextGradedCourse GetInstance()
        {
            if (nextGradedCourse == null)
            {
                nextGradedCourse = Db.NextGradedCourses.SingleOrDefault();

                if (nextGradedCourse == null)
                {
                    nextGradedCourse = new NextGradedCourse();
                    Db.NextGradedCourses.Add(nextGradedCourse);
                    Db.SaveChanges();
                }
            }

            return nextGradedCourse;
        }
    }

    /// <summary>
    /// This models represents the unique number for student
    /// </summary>
    public class NextAuditCourse : NextUniqueNumber
    {
        private static NextAuditCourse nextAuditCourse;

        /// <summary>
        /// Initailizes the NextAuditCourse
        /// </summary>
        private NextAuditCourse()
        {
            this.NextAvailableNumber = 2000;
        }

        public static NextAuditCourse GetInstance()
        {
            if (nextAuditCourse == null)
            {
                nextAuditCourse = Db.NextAuditCourses.SingleOrDefault();

                if (nextAuditCourse == null)
                {
                    nextAuditCourse = new NextAuditCourse();
                    Db.NextAuditCourses.Add(nextAuditCourse);
                    Db.SaveChanges();
                }
            }

            return nextAuditCourse;
        }
    }

    /// <summary>
    /// This models represents the unique number for student
    /// </summary>
    public class NextMasteryCourse : NextUniqueNumber
    {
        private static NextMasteryCourse nextMasteryCourse;

        /// <summary>
        /// Initailizes the NextMasteryCourse
        /// </summary>
        private NextMasteryCourse()
        {
            this.NextAvailableNumber = 20000;
        }

        public static NextMasteryCourse GetInstance()
        {

            if (nextMasteryCourse == null)
            {
                nextMasteryCourse = Db.NextMasteryCourses.SingleOrDefault();

                if (nextMasteryCourse == null)
                {
                    nextMasteryCourse = new NextMasteryCourse();
                    Db.NextMasteryCourses.Add(nextMasteryCourse);
                    Db.SaveChanges();
                }
            }


            return nextMasteryCourse;
        }
    }

    /// <summary>
    /// This models represents the unique number for student
    /// </summary>
    public class NextRegistration : NextUniqueNumber
    {
        private static NextRegistration nextRegistration;

        /// <summary>
        /// Initailizes the NextRegistration
        /// </summary>
        private NextRegistration()
        {
            this.NextAvailableNumber = 700;
        }

        public static NextRegistration GetInstance()
        {
            if (nextRegistration == null)
            {
                nextRegistration = Db.NextRegistrations.SingleOrDefault();

                if (nextRegistration == null)
                {
                    nextRegistration = new NextRegistration();
                    Db.NextRegistrations.Add(nextRegistration);
                    Db.SaveChanges();
                }
            }
            return nextRegistration;
        }
    }

}